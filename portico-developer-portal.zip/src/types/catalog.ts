export type ServiceType = 'service' | 'api' | 'library' | 'pipeline' | 'infra';
export type LifecycleStage = 'production' | 'staging' | 'experimental' | 'deprecated';
export type ServiceTier = 'Tier 1 (Mission Critical)' | 'Tier 2 (Business Essential)' | 'Tier 3 (Supporting)';

export interface ApiEndpoint {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  path: string;
  summary: string;
  description: string;
  authRequired: boolean;
  requestBody?: {
    contentType: string;
    example: Record<string, any>;
  };
  responses: {
    status: number;
    description: string;
    example: Record<string, any>;
  }[];
}

export interface OpenApiSpec {
  version: string;
  title: string;
  description: string;
  baseUrl: string;
  endpoints: ApiEndpoint[];
}

export interface TechDocSection {
  id: string;
  title: string;
  content: string; // Markdown/formatted text
}

export interface DeploymentRecord {
  id: string;
  version: string;
  environment: 'production' | 'staging' | 'canary';
  deployedAt: string;
  deployedBy: string;
  commitHash: string;
  commitMessage: string;
  status: 'healthy' | 'rollback' | 'deploying';
}

export interface ServiceMetrics {
  uptime: number; // e.g. 99.98
  deployFrequency: string; // e.g. "4.2 / day"
  leadTimeHours: number; // e.g. 1.4
  changeFailureRate: number; // e.g. 1.8%
  mttrMinutes: number; // e.g. 14
  p99LatencyMs: number; // e.g. 48
  weeklyRequests: string; // e.g. "140M"
  errorRate: number; // e.g. 0.02%
}

export interface ServiceScorecardRule {
  id: string;
  name: string;
  category: 'security' | 'reliability' | 'observability' | 'docs' | 'quality';
  passed: boolean;
  weight: number;
  description: string;
  remediationSnippet: string;
  severity: 'critical' | 'major' | 'minor';
}

export interface ServiceScorecard {
  overallGrade: 'Platinum' | 'Gold' | 'Silver' | 'Bronze' | 'Needs Review';
  scorePercent: number;
  passedChecks: number;
  totalChecks: number;
  rules: ServiceScorecardRule[];
  lastAudited: string;
}

export interface ServiceEntity {
  id: string;
  name: string;
  description: string;
  type: ServiceType;
  lifecycle: LifecycleStage;
  ownerTeam: string;
  tier: ServiceTier;
  language: string;
  framework: string;
  repository: string;
  runbookUrl: string;
  slackChannel: string;
  createdAt: string;
  updatedAt: string;
  dependencies: {
    upstream: string[];
    downstream: string[];
    databases: string[];
    queues: string[];
  };
  metrics: ServiceMetrics;
  tags: string[];
  openApiSpec?: OpenApiSpec;
  techDocs?: TechDocSection[];
  scorecard: ServiceScorecard;
  deployments: DeploymentRecord[];
  kubernetes: {
    cluster: string;
    namespace: string;
    replicas: number;
    cpuUsage: string;
    memoryUsage: string;
    restarts24h: number;
  };
}
