export interface TemplateParameter {
  name: string;
  label: string;
  type: 'string' | 'select' | 'boolean' | 'multiselect';
  description: string;
  defaultValue?: any;
  options?: { label: string; value: string }[];
  required?: boolean;
}

export interface TemplateStep {
  id: string;
  title: string;
  description: string;
  action: string;
  estimatedSeconds: number;
}

export interface GoldenPathTemplate {
  id: string;
  name: string;
  description: string;
  category: 'Backend Microservice' | 'API Gateway' | 'Data & Streaming' | 'Frontend Web' | 'Cloud Infrastructure';
  language: string;
  framework: string;
  author: string;
  recommendedFor: string;
  iconName: string;
  tags: string[];
  parameters: TemplateParameter[];
  executionSteps: TemplateStep[];
  includedAddons: string[];
  sampleRepoUrl: string;
  version: string;
  stars: number;
}

export interface ScaffoldExecutionLog {
  timestamp: string;
  level: 'info' | 'success' | 'warn' | 'error';
  message: string;
  stepId?: string;
}
