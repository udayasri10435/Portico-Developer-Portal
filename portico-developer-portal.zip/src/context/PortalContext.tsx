import React, { createContext, useContext, useState, useEffect } from 'react';
import { ServiceEntity } from '../types/catalog';
import { GoldenPathTemplate, ScaffoldExecutionLog } from '../types/template';
import { INITIAL_SERVICES } from '../data/mockCatalog';
import { INITIAL_TEMPLATES } from '../data/mockTemplates';

export type NavigationTab = 'catalog' | 'scaffolder' | 'scorecards' | 'techdocs' | 'graph' | 'dora';

interface PortalContextType {
  services: ServiceEntity[];
  templates: GoldenPathTemplate[];
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  selectedService: ServiceEntity | null;
  setSelectedServiceId: (id: string | null) => void;
  selectedTemplate: GoldenPathTemplate | null;
  setSelectedTemplate: (template: GoldenPathTemplate | null) => void;
  isScaffolderModalOpen: boolean;
  setIsScaffolderModalOpen: (open: boolean) => void;
  isCommandPaletteOpen: boolean;
  setIsCommandPaletteOpen: (open: boolean) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  auditDrawerService: ServiceEntity | null;
  setAuditDrawerServiceId: (id: string | null) => void;
  // Actions
  toggleScorecardCheck: (serviceId: string, ruleId: string) => void;
  reAuditAllChecks: (serviceId: string) => void;
  addNewService: (service: ServiceEntity) => void;
  addNewTemplate: (template: GoldenPathTemplate) => void;
  resetAllData: () => void;
}

const PortalContext = createContext<PortalContextType | undefined>(undefined);

const LOCAL_STORAGE_SERVICES_KEY = 'portico_idp_services_v2';
const LOCAL_STORAGE_TEMPLATES_KEY = 'portico_idp_templates_v2';

export const PortalProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [services, setServices] = useState<ServiceEntity[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_SERVICES_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load services from localStorage', e);
    }
    return INITIAL_SERVICES;
  });

  const [templates, setTemplates] = useState<GoldenPathTemplate[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_TEMPLATES_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load templates from localStorage', e);
    }
    return INITIAL_TEMPLATES;
  });

  const [activeTab, setActiveTab] = useState<NavigationTab>('catalog');
  const [selectedServiceId, setSelectedServiceId] = useState<string | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<GoldenPathTemplate | null>(null);
  const [isScaffolderModalOpen, setIsScaffolderModalOpen] = useState(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [auditDrawerServiceId, setAuditDrawerServiceId] = useState<string | null>(null);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_SERVICES_KEY, JSON.stringify(services));
    } catch (e) {
      console.error('Failed to save services to localStorage', e);
    }
  }, [services]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_TEMPLATES_KEY, JSON.stringify(templates));
    } catch (e) {
      console.error('Failed to save templates to localStorage', e);
    }
  }, [templates]);

  // Global keydown listener for Command+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      }
      if (e.key === 'Escape') {
        setIsCommandPaletteOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const selectedService = services.find((s) => s.id === selectedServiceId) || null;
  const auditDrawerService = services.find((s) => s.id === auditDrawerServiceId) || null;

  const toggleScorecardCheck = (serviceId: string, ruleId: string) => {
    setServices((prev) =>
      prev.map((svc) => {
        if (svc.id !== serviceId) return svc;
        const updatedRules = svc.scorecard.rules.map((rule) => {
          if (rule.id !== ruleId) return rule;
          return { ...rule, passed: !rule.passed };
        });

        const passedCount = updatedRules.filter((r) => r.passed).length;
        const total = updatedRules.length;
        const percent = Math.round((passedCount / total) * 100);

        let grade: 'Platinum' | 'Gold' | 'Silver' | 'Bronze' | 'Needs Review' = 'Needs Review';
        if (percent === 100) grade = 'Platinum';
        else if (percent >= 85) grade = 'Gold';
        else if (percent >= 70) grade = 'Silver';
        else if (percent >= 50) grade = 'Bronze';

        return {
          ...svc,
          scorecard: {
            ...svc.scorecard,
            rules: updatedRules,
            passedChecks: passedCount,
            totalChecks: total,
            scorePercent: percent,
            overallGrade: grade,
            lastAudited: 'Just now'
          }
        };
      })
    );
  };

  const reAuditAllChecks = (serviceId: string) => {
    setServices((prev) =>
      prev.map((svc) => {
        if (svc.id !== serviceId) return svc;
        // Mark all rules as audited and update timestamp
        return {
          ...svc,
          scorecard: {
            ...svc.scorecard,
            lastAudited: 'Just now'
          }
        };
      })
    );
  };

  const addNewService = (newSvc: ServiceEntity) => {
    setServices((prev) => [newSvc, ...prev]);
    setSelectedServiceId(newSvc.id);
  };

  const addNewTemplate = (newTmpl: GoldenPathTemplate) => {
    setTemplates((prev) => [newTmpl, ...prev]);
  };

  const resetAllData = () => {
    localStorage.removeItem(LOCAL_STORAGE_SERVICES_KEY);
    localStorage.removeItem(LOCAL_STORAGE_TEMPLATES_KEY);
    setServices(INITIAL_SERVICES);
    setTemplates(INITIAL_TEMPLATES);
  };

  return (
    <PortalContext.Provider
      value={{
        services,
        templates,
        activeTab,
        setActiveTab,
        selectedService,
        setSelectedServiceId,
        selectedTemplate,
        setSelectedTemplate,
        isScaffolderModalOpen,
        setIsScaffolderModalOpen,
        isCommandPaletteOpen,
        setIsCommandPaletteOpen,
        searchQuery,
        setSearchQuery,
        auditDrawerService,
        setAuditDrawerServiceId,
        toggleScorecardCheck,
        reAuditAllChecks,
        addNewService,
        addNewTemplate,
        resetAllData
      }}
    >
      {children}
    </PortalContext.Provider>
  );
};

export const usePortal = () => {
  const context = useContext(PortalContext);
  if (!context) {
    throw new Error('usePortal must be used within a PortalProvider');
  }
  return context;
};
