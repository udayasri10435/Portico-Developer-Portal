/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { PortalProvider, usePortal } from './context/PortalContext';
import { Header } from './components/layout/Header';
import { CommandPalette } from './components/layout/CommandPalette';
import { ServiceCatalogView } from './components/catalog/ServiceCatalogView';
import { GoldenPathsView } from './components/scaffolder/GoldenPathsView';
import { ScorecardsView } from './components/scorecards/ScorecardsView';
import { TechDocsView } from './components/docs/TechDocsView';
import { SystemGraphView } from './components/graph/SystemGraphView';
import { DoraMetricsView } from './components/dora/DoraMetricsView';
import { ScaffolderWizardModal } from './components/scaffolder/ScaffolderWizardModal';
import { ScorecardAuditDrawer } from './components/scorecards/ScorecardAuditDrawer';

const MainPortalContent: React.FC = () => {
  const { activeTab, isScaffolderModalOpen, setIsScaffolderModalOpen, selectedTemplate, resetAllData } = usePortal();

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100 font-sans">
      <Header />

      <main className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 py-6">
        {activeTab === 'catalog' && <ServiceCatalogView />}
        {activeTab === 'scaffolder' && <GoldenPathsView />}
        {activeTab === 'scorecards' && <ScorecardsView />}
        {activeTab === 'techdocs' && <TechDocsView />}
        {activeTab === 'graph' && <SystemGraphView />}
        {activeTab === 'dora' && <DoraMetricsView />}
      </main>

      {/* Global Modals & Drawers */}
      <CommandPalette />
      {isScaffolderModalOpen && (
        <ScaffolderWizardModal
          template={selectedTemplate}
          onClose={() => setIsScaffolderModalOpen(false)}
        />
      )}
      <ScorecardAuditDrawer />

      {/* Footer adhering to quiet footer rules */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 text-xs text-slate-500">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">Portico IDP</span>
            <span aria-hidden="true">·</span>
            <span>Backstage-as-a-Service Platform</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={resetAllData}
              className="text-slate-500 hover:text-slate-300 transition-colors"
            >
              Reset Demo Data
            </button>
            <span aria-hidden="true">·</span>
            <span>Internal Engineering Guild</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <PortalProvider>
      <MainPortalContent />
    </PortalProvider>
  );
}
