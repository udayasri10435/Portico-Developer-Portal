import { GoldenPathTemplate } from '../types/template';

export const INITIAL_TEMPLATES: GoldenPathTemplate[] = [
  {
    id: 'tmpl-go-grpc',
    name: 'Production Go 1.23 gRPC & REST Service',
    description: 'Battle-tested high-throughput microservice template. Bundles Buf protobuf compiler, OpenTelemetry distributed tracing, Chainguard distroless container, and ArgoCD Helm manifests.',
    category: 'Backend Microservice',
    language: 'Go',
    framework: 'Gin & gRPC v1.62',
    author: 'Platform Core Team',
    recommendedFor: 'High-throughput low-latency microservices, financial calculations, and edge proxies.',
    iconName: 'Cpu',
    version: 'v3.2.0',
    stars: 142,
    sampleRepoUrl: 'github.com/acme-templates/go-grpc-goldenpath',
    tags: ['go', 'grpc', 'opentelemetry', 'distroless', 'tier-1-ready'],
    includedAddons: [
      'OpenTelemetry W3C trace propagation',
      'Prometheus /metrics endpoint',
      'Chainguard static-debian12 distroless Dockerfile',
      'GitHub Actions CI with Trivy security scanner',
      'ArgoCD GitOps application manifest',
      'Pre-configured /healthz and /readyz probes'
    ],
    parameters: [
      {
        name: 'serviceName',
        label: 'Service Name',
        type: 'string',
        description: 'Lowercase alphanumeric kebab-case name (e.g. payout-calculator)',
        required: true
      },
      {
        name: 'description',
        label: 'Service Description',
        type: 'string',
        description: 'Single-sentence summary of component responsibility',
        required: true
      },
      {
        name: 'ownerTeam',
        label: 'Owner Team',
        type: 'select',
        description: 'Squad responsible for maintenance and on-call escalation',
        required: true,
        options: [
          { label: 'Identity & Access', value: 'Identity & Access' },
          { label: 'Checkout & Payments', value: 'Checkout & Payments' },
          { label: 'Platform Core', value: 'Platform Core' },
          { label: 'Supply Chain & Fulfillment', value: 'Supply Chain & Fulfillment' },
          { label: 'Data Eng & Search', value: 'Data Eng & Search' }
        ]
      },
      {
        name: 'tier',
        label: 'Service Tier',
        type: 'select',
        description: 'Criticality level and uptime SLA expectations',
        required: true,
        defaultValue: 'Tier 1 (Mission Critical)',
        options: [
          { label: 'Tier 1 (Mission Critical - 99.99%)', value: 'Tier 1 (Mission Critical)' },
          { label: 'Tier 2 (Business Essential - 99.9%)', value: 'Tier 2 (Business Essential)' },
          { label: 'Tier 3 (Internal Supporting - 99.5%)', value: 'Tier 3 (Supporting)' }
        ]
      },
      {
        name: 'databaseAddon',
        label: 'Database Provisioning',
        type: 'select',
        description: 'Automate Cloud SQL or in-memory persistence binding',
        defaultValue: 'postgres',
        options: [
          { label: 'PostgreSQL 16 (Dedicated Cloud SQL)', value: 'postgres' },
          { label: 'Redis 7.2 (Session / Cache Cluster)', value: 'redis' },
          { label: 'PostgreSQL + Redis Combined', value: 'both' },
          { label: 'Stateless (No Database)', value: 'none' }
        ]
      },
      {
        name: 'enableTracing',
        label: 'Enable OpenTelemetry Distributed Tracing',
        type: 'boolean',
        description: 'Inject OTLP exporter pointing to company collector daemon',
        defaultValue: true
      },
      {
        name: 'enableVault',
        label: 'Enable Vault Dynamic Secrets Agent',
        type: 'boolean',
        description: 'Mount HashiCorp Vault sidecar for zero-trust token leases',
        defaultValue: true
      }
    ],
    executionSteps: [
      {
        id: 'step-clone',
        title: 'Fetch Golden Path Scaffold',
        description: 'Cloning template repo from git:acme-templates/go-grpc-goldenpath.git@v3.2.0',
        action: 'git:clone',
        estimatedSeconds: 1
      },
      {
        id: 'step-template',
        title: 'Template Variables Substitution',
        description: 'Compiling cookiecutter parameters (service_name, module_path, team_owner)',
        action: 'template:render',
        estimatedSeconds: 2
      },
      {
        id: 'step-catalog',
        title: 'Register in IDP Service Catalog',
        description: 'Generating compliant catalog-info.yaml and registering component entity',
        action: 'catalog:register',
        estimatedSeconds: 1
      },
      {
        id: 'step-repo',
        title: 'Create Enterprise GitHub Repository',
        description: 'Creating repo, setting main branch protection, CODEOWNERS, and secrets',
        action: 'github:repo:create',
        estimatedSeconds: 2
      },
      {
        id: 'step-argocd',
        title: 'Provision ArgoCD GitOps Pipeline',
        description: 'Registering Application in cluster gitops repo with automated sync & self-heal',
        action: 'argocd:app:create',
        estimatedSeconds: 2
      },
      {
        id: 'step-vault',
        title: 'Configure Vault Secret Engine Role',
        description: 'Issuing Kubernetes service account token binding with least-privilege IAM',
        action: 'vault:policy:bind',
        estimatedSeconds: 1
      }
    ]
  },
  {
    id: 'tmpl-node-fastify',
    name: 'Node.js & TypeScript Fastify REST API',
    description: 'Ultra-fast TypeScript API with Zod request validation, Prisma ORM, OpenAPI/Swagger auto-generation, and Vitest test suite.',
    category: 'Backend Microservice',
    language: 'TypeScript / Node.js',
    framework: 'Fastify v4.28 / Prisma',
    author: 'Frontend & API Guild',
    recommendedFor: 'Internal micro-APIs, developer productivity backends, and BFF (Backend-for-Frontend) aggregators.',
    iconName: 'Server',
    version: 'v2.8.1',
    stars: 98,
    sampleRepoUrl: 'github.com/acme-templates/node-fastify-goldenpath',
    tags: ['typescript', 'fastify', 'prisma', 'zod', 'openapi', 'swagger'],
    includedAddons: [
      'Zod schema validation with automatic OpenAPI 3.0 generation',
      'Prisma ORM with migration scripts',
      'OpenTelemetry Node SDK with HTTP auto-patching',
      'Vitest + Supertest integration testing harness',
      'Docker multi-stage builder for minimal image size'
    ],
    parameters: [
      {
        name: 'serviceName',
        label: 'Service Name',
        type: 'string',
        description: 'e.g. member-rewards-api',
        required: true
      },
      {
        name: 'description',
        label: 'Description',
        type: 'string',
        description: 'Short summary of the REST API',
        required: true
      },
      {
        name: 'ownerTeam',
        label: 'Owner Team',
        type: 'select',
        description: 'Squad responsible',
        required: true,
        options: [
          { label: 'Growth & Frontend', value: 'Growth & Frontend' },
          { label: 'Checkout & Payments', value: 'Checkout & Payments' },
          { label: 'Platform Core', value: 'Platform Core' }
        ]
      },
      {
        name: 'tier',
        label: 'Tier',
        type: 'select',
        description: 'Service criticality',
        defaultValue: 'Tier 2 (Business Essential)',
        options: [
          { label: 'Tier 1 (Mission Critical)', value: 'Tier 1 (Mission Critical)' },
          { label: 'Tier 2 (Business Essential)', value: 'Tier 2 (Business Essential)' },
          { label: 'Tier 3 (Supporting)', value: 'Tier 3 (Supporting)' }
        ]
      }
    ],
    executionSteps: [
      {
        id: 'step-clone',
        title: 'Fetch Fastify Template Repository',
        description: 'Cloning fastify-starter v2.8.1',
        action: 'git:clone',
        estimatedSeconds: 1
      },
      {
        id: 'step-template',
        title: 'Render TypeScript Package Files',
        description: 'Substituting package.json, prisma/schema.prisma, and catalog-info.yaml',
        action: 'template:render',
        estimatedSeconds: 2
      },
      {
        id: 'step-github',
        title: 'Publish to GitHub & Set Actions CI',
        description: 'Setting lint, typecheck, and test GitHub Actions workflows',
        action: 'github:publish',
        estimatedSeconds: 2
      },
      {
        id: 'step-catalog',
        title: 'Register in IDP Catalog',
        description: 'Registering entity with auto-publishing TechDocs hook',
        action: 'catalog:register',
        estimatedSeconds: 1
      }
    ]
  },
  {
    id: 'tmpl-python-worker',
    name: 'Event-Driven Python Kafka Worker',
    description: 'AsyncIO consumer service for high-volume streaming data. Includes dead-letter queue (DLQ) retry semantics, Pydantic schemas, and KEDA auto-scaling.',
    category: 'Data & Streaming',
    language: 'Python',
    framework: 'FastAPI / aiokafka / Pydantic v2',
    author: 'Data Platform Squad',
    recommendedFor: 'Asynchronous event consumption, ETL stream parsing, and webhook forwarding.',
    iconName: 'Activity',
    version: 'v2.4.0',
    stars: 87,
    sampleRepoUrl: 'github.com/acme-templates/python-kafka-worker',
    tags: ['python', 'kafka', 'asyncio', 'keda', 'dlq', 'streaming'],
    includedAddons: [
      'aiokafka consumer group with backoff retry',
      'Automatic Dead Letter Queue (DLQ) failover',
      'Kubernetes Event-driven Autoscaling (KEDA) trigger configuration',
      'Ruff linter + Mypy strict type checking',
      'Tox test runner with pytest-asyncio'
    ],
    parameters: [
      {
        name: 'serviceName',
        label: 'Worker Name',
        type: 'string',
        description: 'e.g. order-sync-worker',
        required: true
      },
      {
        name: 'description',
        label: 'Worker Purpose',
        type: 'string',
        description: 'What events does this worker process?',
        required: true
      },
      {
        name: 'kafkaTopic',
        label: 'Inbound Kafka Topic',
        type: 'string',
        description: 'e.g. commerce.orders.v1',
        required: true,
        defaultValue: 'events.inbound.v1'
      },
      {
        name: 'ownerTeam',
        label: 'Owner Team',
        type: 'select',
        description: 'Squad responsible',
        required: true,
        options: [
          { label: 'Data Eng & Search', value: 'Data Eng & Search' },
          { label: 'Platform Core', value: 'Platform Core' },
          { label: 'Supply Chain & Fulfillment', value: 'Supply Chain & Fulfillment' }
        ]
      }
    ],
    executionSteps: [
      {
        id: 'step-clone',
        title: 'Clone Python Worker Template',
        description: 'Pulling verified async worker skeleton',
        action: 'git:clone',
        estimatedSeconds: 1
      },
      {
        id: 'step-template',
        title: 'Configure Kafka Topics & Consumer Group',
        description: 'Binding topic names, DLQ routing, and consumer group ID',
        action: 'template:render',
        estimatedSeconds: 2
      },
      {
        id: 'step-keda',
        title: 'Generate KEDA Autoscaler ScaledObject',
        description: 'Configuring lag-based HPA scaling from 2 to 20 pods',
        action: 'k8s:keda:configure',
        estimatedSeconds: 1
      },
      {
        id: 'step-catalog',
        title: 'Register in IDP Catalog',
        description: 'Injecting catalog metadata into Portico',
        action: 'catalog:register',
        estimatedSeconds: 1
      }
    ]
  },
  {
    id: 'tmpl-react-internal',
    name: 'Internal Platform Web App (React / Vite)',
    description: 'Enterprise React single-page application with corporate SSO login, Tailwind CSS design system tokens, and automated preview environments.',
    category: 'Frontend Web',
    language: 'TypeScript / React',
    framework: 'React 19 / Vite / Tailwind',
    author: 'Frontend & API Guild',
    recommendedFor: 'Internal operational dashboards, support tooling, and executive analytics.',
    iconName: 'Layout',
    version: 'v4.1.0',
    stars: 115,
    sampleRepoUrl: 'github.com/acme-templates/internal-tool-react',
    tags: ['react', 'vite', 'tailwind', 'sso', 'oidc', 'internal-tooling'],
    includedAddons: [
      'Corporate OIDC / Okta SSO authentication provider',
      'Enterprise design system components with Tailwind CSS',
      'Automated PR preview URLs via Cloudflare Pages',
      'Pre-configured Playwright end-to-end smoke test suite'
    ],
    parameters: [
      {
        name: 'serviceName',
        label: 'Application Name',
        type: 'string',
        description: 'e.g. operations-support-portal',
        required: true
      },
      {
        name: 'description',
        label: 'Description',
        type: 'string',
        description: 'What internal business process does this portal support?',
        required: true
      },
      {
        name: 'ownerTeam',
        label: 'Owner Team',
        type: 'select',
        description: 'Owning team',
        required: true,
        options: [
          { label: 'Growth & Frontend', value: 'Growth & Frontend' },
          { label: 'Platform Core', value: 'Platform Core' },
          { label: 'Supply Chain & Fulfillment', value: 'Supply Chain & Fulfillment' }
        ]
      }
    ],
    executionSteps: [
      {
        id: 'step-clone',
        title: 'Pull React Vite Starter',
        description: 'Fetching UI template with company design system',
        action: 'git:clone',
        estimatedSeconds: 1
      },
      {
        id: 'step-template',
        title: 'Inject OIDC Client IDs & Routes',
        description: 'Configuring auth context and environment variables',
        action: 'template:render',
        estimatedSeconds: 2
      },
      {
        id: 'step-cloudflare',
        title: 'Provision Cloudflare Pages Project',
        description: 'Linking GitHub repository for zero-downtime previews',
        action: 'cloudflare:pages:create',
        estimatedSeconds: 2
      },
      {
        id: 'step-catalog',
        title: 'Register in IDP Catalog',
        description: 'Publishing entity and documentation link',
        action: 'catalog:register',
        estimatedSeconds: 1
      }
    ]
  },
  {
    id: 'tmpl-terraform-module',
    name: 'Cloud Infrastructure Terraform Module',
    description: 'Vetted multi-environment Terraform module with strict AWS/GCP KMS encryption, automated IAM least-privilege policies, and Terratest harness.',
    category: 'Cloud Infrastructure',
    language: 'Terraform',
    framework: 'Terraform 1.9 / Terratest',
    author: 'Cloud Infra & SRE Guild',
    recommendedFor: 'Infrastructure engineers provisioning VPCs, database clusters, or Kubernetes node pools.',
    iconName: 'Cloud',
    version: 'v2.2.0',
    stars: 64,
    sampleRepoUrl: 'github.com/acme-templates/terraform-module-goldenpath',
    tags: ['terraform', 'iac', 'aws', 'gcp', 'terratest', 'security'],
    includedAddons: [
      'TFLint + Trivy Terraform security scanner',
      'Automated semantic versioning & tag release pipeline',
      'Terratest Go-based automated integration tests',
      'Mandatory corporate tagging standard enforcement'
    ],
    parameters: [
      {
        name: 'serviceName',
        label: 'Module Name',
        type: 'string',
        description: 'e.g. terraform-gke-secure-cluster',
        required: true
      },
      {
        name: 'description',
        label: 'Module Purpose',
        type: 'string',
        description: 'What cloud resource does this module provision?',
        required: true
      },
      {
        name: 'ownerTeam',
        label: 'Owner Team',
        type: 'select',
        description: 'Owning team',
        defaultValue: 'Platform Core',
        options: [
          { label: 'Platform Core', value: 'Platform Core' },
          { label: 'Data Eng & Search', value: 'Data Eng & Search' }
        ]
      }
    ],
    executionSteps: [
      {
        id: 'step-clone',
        title: 'Clone Terraform Module Skeleton',
        description: 'Fetching standardized module structure',
        action: 'git:clone',
        estimatedSeconds: 1
      },
      {
        id: 'step-template',
        title: 'Render Variables and Provider Constraints',
        description: 'Generating main.tf, variables.tf, outputs.tf, and README.md',
        action: 'template:render',
        estimatedSeconds: 2
      },
      {
        id: 'step-registry',
        title: 'Publish to Internal Private Module Registry',
        description: 'Registering module in corporate Terraform Cloud registry',
        action: 'tfe:registry:publish',
        estimatedSeconds: 2
      },
      {
        id: 'step-catalog',
        title: 'Register in IDP Catalog',
        description: 'Publishing as an infrastructure component in Portico',
        action: 'catalog:register',
        estimatedSeconds: 1
      }
    ]
  }
];
