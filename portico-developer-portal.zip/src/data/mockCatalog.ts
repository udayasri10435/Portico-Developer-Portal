import { ServiceEntity } from '../types/catalog';

export const INITIAL_SERVICES: ServiceEntity[] = [
  {
    id: 'auth-gateway',
    name: 'auth-gateway',
    description: 'Central OAuth2, OIDC & JWT session minting authority with distributed mTLS edge verification.',
    type: 'service',
    lifecycle: 'production',
    ownerTeam: 'Identity & Access',
    tier: 'Tier 1 (Mission Critical)',
    language: 'Go',
    framework: 'Gin / gRPC v1.58',
    repository: 'github.com/acme/auth-gateway',
    runbookUrl: 'https://runbooks.corp.internal/auth-gateway',
    slackChannel: '#team-identity-alerts',
    createdAt: '2024-02-15',
    updatedAt: '2026-09-24',
    dependencies: {
      upstream: ['edge-proxy-ingress', 'customer-web-portal', 'checkout-orchestrator'],
      downstream: ['fraud-risk-evaluator', 'notification-dispatcher'],
      databases: ['PostgreSQL (User Store)', 'Redis Cluster (Session Cache)'],
      queues: ['Kafka topic: auth.events.v1']
    },
    metrics: {
      uptime: 99.995,
      deployFrequency: '6.4 / day',
      leadTimeHours: 0.8,
      changeFailureRate: 0.8,
      mttrMinutes: 8,
      p99LatencyMs: 14,
      weeklyRequests: '482M',
      errorRate: 0.003
    },
    tags: ['oauth2', 'jwt', 'security', 'critical-path', 'zero-trust'],
    kubernetes: {
      cluster: 'prod-us-east4-gke',
      namespace: 'security-core',
      replicas: 18,
      cpuUsage: '34%',
      memoryUsage: '4.8 GB',
      restarts24h: 0
    },
    scorecard: {
      overallGrade: 'Platinum',
      scorePercent: 100,
      passedChecks: 12,
      totalChecks: 12,
      lastAudited: '2026-09-28',
      rules: [
        {
          id: 'sec-01',
          name: 'Zero Critical CVEs',
          category: 'security',
          passed: true,
          weight: 15,
          severity: 'critical',
          description: 'Trivy container scanner detects 0 Critical or High severity vulnerabilities in latest sha256 digest.',
          remediationSnippet: 'Run: docker run --rm -v /var/run/docker.sock:/var/run/docker.sock aquasec/trivy image auth-gateway:latest'
        },
        {
          id: 'sec-02',
          name: 'Branch Protection & 2 Reviewers',
          category: 'security',
          passed: true,
          weight: 10,
          severity: 'major',
          description: 'GitHub default branch requires strict signed commits, passing CI, and minimum 2 senior approvals.',
          remediationSnippet: 'gh api --method PUT repos/acme/auth-gateway/branches/main/protection'
        },
        {
          id: 'sec-03',
          name: 'Automated Secrets Scanning',
          category: 'security',
          passed: true,
          weight: 10,
          severity: 'critical',
          description: 'Gitleaks & HashiCorp Vault dynamic secret lease integration verified with no hardcoded tokens.',
          remediationSnippet: 'gitleaks detect --source . --verbose'
        },
        {
          id: 'rel-01',
          name: 'Kubernetes Liveness & Readiness Probes',
          category: 'reliability',
          passed: true,
          weight: 10,
          severity: 'critical',
          description: 'Active HTTP probes at /healthz and /ready with timeoutSeconds: 2 and failureThreshold: 3.',
          remediationSnippet: 'livenessProbe:\n  httpGet:\n    path: /healthz\n    port: 8080\n  initialDelaySeconds: 5'
        },
        {
          id: 'rel-02',
          name: 'Graceful SIGTERM Drain Handled',
          category: 'reliability',
          passed: true,
          weight: 10,
          severity: 'major',
          description: 'HTTP server waits 15s to drain active connections on SIGTERM before process exit.',
          remediationSnippet: 'ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGTERM)\n<-ctx.Done()\nsrv.Shutdown(timeoutCtx)'
        },
        {
          id: 'rel-03',
          name: 'SLO Alert Defined in Datadog',
          category: 'reliability',
          passed: true,
          weight: 10,
          severity: 'critical',
          description: '99.95% availability SLO defined with burn rate alert routed directly to PagerDuty.',
          remediationSnippet: 'datadog_service_level_objective "auth_uptime" { target = 99.95 }'
        },
        {
          id: 'obs-01',
          name: 'OpenTelemetry W3C Distributed Tracing',
          category: 'observability',
          passed: true,
          weight: 10,
          severity: 'major',
          description: 'Incoming traceparent headers propagated downstream to all HTTP and gRPC calls.',
          remediationSnippet: 'otel.SetTextMapPropagator(propagation.NewCompositeTextMapPropagator(propagation.TraceContext{}))'
        },
        {
          id: 'obs-02',
          name: 'Structured JSON Logging with Trace IDs',
          category: 'observability',
          passed: true,
          weight: 5,
          severity: 'minor',
          description: 'Logs emit JSON format with timestamp, level, trace_id, and span_id fields.',
          remediationSnippet: 'slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{}))'
        },
        {
          id: 'doc-01',
          name: 'catalog-info.yaml Validated',
          category: 'docs',
          passed: true,
          weight: 5,
          severity: 'major',
          description: 'Repository contains verified backstage catalog-info.yaml with valid schema.',
          remediationSnippet: 'yq eval .catalog-info.yaml'
        },
        {
          id: 'doc-02',
          name: 'OpenAPI 3.0 Contract Synchronized',
          category: 'docs',
          passed: true,
          weight: 5,
          severity: 'minor',
          description: 'Swagger/OpenAPI spec exported automatically during CI build.',
          remediationSnippet: 'go run tools/gen-openapi.go -out docs/openapi.yaml'
        },
        {
          id: 'qty-01',
          name: 'Unit Test Coverage >= 85%',
          category: 'quality',
          passed: true,
          weight: 5,
          severity: 'minor',
          description: 'Code coverage currently at 91.4% with branch evaluation enabled.',
          remediationSnippet: 'go test -race -coverprofile=coverage.out ./...'
        },
        {
          id: 'qty-02',
          name: 'Distroless Container Base Image',
          category: 'quality',
          passed: true,
          weight: 5,
          severity: 'minor',
          description: 'Final production Docker image uses gcr.io/distroless/static-debian12 non-root user.',
          remediationSnippet: 'FROM gcr.io/distroless/static-debian12:nonroot\nUSER nonroot:nonroot'
        }
      ]
    },
    deployments: [
      {
        id: 'dep-901',
        version: 'v2.14.0',
        environment: 'production',
        deployedAt: '2026-09-28 14:22 UTC',
        deployedBy: 'ArgoCD Sync (sha: 7a8f192)',
        commitHash: '7a8f192',
        commitMessage: 'feat(jwt): add ed25519 key rotation support',
        status: 'healthy'
      },
      {
        id: 'dep-900',
        version: 'v2.13.2',
        environment: 'production',
        deployedAt: '2026-09-26 09:10 UTC',
        deployedBy: 'alex.rivera',
        commitHash: '1c04ba2',
        commitMessage: 'fix(redis): optimize connection pool idle timeout',
        status: 'healthy'
      }
    ],
    openApiSpec: {
      version: '3.0.3',
      title: 'Auth Gateway Edge API',
      description: 'Zero-trust identity assertion, mTLS handshake and token issuance services.',
      baseUrl: 'https://auth.internal.corp/v1',
      endpoints: [
        {
          method: 'POST',
          path: '/oauth2/token',
          summary: 'Mint Bearer Token',
          description: 'Exchanges client credentials or authorization code for an asymmetric JWT session.',
          authRequired: true,
          requestBody: {
            contentType: 'application/json',
            example: {
              grant_type: 'client_credentials',
              client_id: 'svc-checkout-01',
              client_secret: '••••••••••••••••',
              scope: 'payments:write transactions:read'
            }
          },
          responses: [
            {
              status: 200,
              description: 'Token successfully generated',
              example: {
                access_token: 'eyJhbGciOiJFRDI1NTE5IiwidHlwIjoiSldUIn0.example',
                token_type: 'Bearer',
                expires_in: 3600,
                refresh_token: 'rfr_904128a9b7410f',
                scope: 'payments:write transactions:read'
              }
            },
            {
              status: 401,
              description: 'Invalid client credentials',
              example: { error: 'invalid_client', error_description: 'Client secret mismatch' }
            }
          ]
        },
        {
          method: 'GET',
          path: '/sessions/introspect',
          summary: 'Introspect Active Token',
          description: 'Validates token signature, expiration, and revocation status from Redis blacklist.',
          authRequired: true,
          responses: [
            {
              status: 200,
              description: 'Token details & principal identity',
              example: {
                active: true,
                sub: 'usr_89214730',
                client_id: 'customer-portal',
                exp: 1790697600,
                iss: 'https://auth.internal.corp',
                roles: ['engineer', 'admin:read']
              }
            }
          ]
        },
        {
          method: 'GET',
          path: '/.well-known/jwks.json',
          summary: 'Public JWKS Key Set',
          description: 'Returns active public keys for offline signature verification in downstream services.',
          authRequired: false,
          responses: [
            {
              status: 200,
              description: 'JSON Web Key Set',
              example: {
                keys: [
                  {
                    kty: 'OKP',
                    crv: 'Ed25519',
                    kid: '2026-q3-key',
                    x: '11qYAYKxCrfVS_7TyWQHOg7hcvPapiMlrGwRxnxMDuu'
                  }
                ]
              }
            }
          ]
        }
      ]
    },
    techDocs: [
      {
        id: 'arch-overview',
        title: 'Architecture Overview',
        content: `### High-Throughput Auth Architecture

The **auth-gateway** is an enterprise-scale authentication proxy terminating internal and customer authentication traffic.

#### Key Principles:
1. **Asymmetric Key Rotation**: Public verification keys are broadcast to downstream services via JWKS cache with a 15-minute TTL.
2. **Stateless Edge Validation**: Microservices verify signatures locally without calling auth-gateway over the wire for every request.
3. **Revocation List via Redis Pub/Sub**: When an account is locked or logged out, a revocation event is published to all gateway nodes in < 12ms.

\`\`\`
[ Client / Web App ]
         │ (TLS 1.3)
         ▼
[ Ingress Gateway ]
         │ (mTLS)
         ▼
[ auth-gateway (Go) ] ──▶ [ Redis Session Cache ]
         │
         ├──▶ [ PostgreSQL Identity DB ]
         └──▶ [ Kafka auth.events ]
\`\`\`
`
      },
      {
        id: 'runbook-incidents',
        title: 'Runbook: High Latency & Spike Escalation',
        content: `### Incident Response Playbook

#### Severity 1: p99 Latency > 100ms
1. **Check Redis Connection Pool**: Verify if connection pool saturation is occurring:
   \`kubectl logs -n security-core -l app=auth-gateway | grep "redis: connection pool exhausted"\`
2. **Horizontal Pod Autoscaling**:
   \`kubectl scale deployment/auth-gateway -n security-core --replicas=30\`
3. **Failover Read-Replicas**:
   If PostgreSQL primary is experiencing lock contention, toggle replica routing in Consul KV:
   \`consul kv put config/auth/use_read_pool true\`
`
      }
    ]
  },
  {
    id: 'checkout-orchestrator',
    name: 'checkout-orchestrator',
    description: 'Coordinates multi-step shopping basket validation, payment hold, inventory lock, and tax computation.',
    type: 'service',
    lifecycle: 'production',
    ownerTeam: 'Checkout & Payments',
    tier: 'Tier 1 (Mission Critical)',
    language: 'TypeScript / Node.js',
    framework: 'Fastify v4.26',
    repository: 'github.com/acme/checkout-orchestrator',
    runbookUrl: 'https://runbooks.corp.internal/checkout-orchestrator',
    slackChannel: '#checkout-war-room',
    createdAt: '2024-05-10',
    updatedAt: '2026-09-25',
    dependencies: {
      upstream: ['customer-web-portal', 'edge-proxy-ingress'],
      downstream: ['billing-engine', 'inventory-service', 'fraud-risk-evaluator', 'notification-dispatcher'],
      databases: ['PostgreSQL (Orders Ledger)', 'Redis (Lock Manager)'],
      queues: ['Kafka: order.created.v2', 'Kafka: checkout.aborted']
    },
    metrics: {
      uptime: 99.98,
      deployFrequency: '4.8 / day',
      leadTimeHours: 1.2,
      changeFailureRate: 1.4,
      mttrMinutes: 12,
      p99LatencyMs: 82,
      weeklyRequests: '94M',
      errorRate: 0.015
    },
    tags: ['checkout', 'ecommerce', 'saga-pattern', 'financial'],
    kubernetes: {
      cluster: 'prod-us-east4-gke',
      namespace: 'commerce',
      replicas: 12,
      cpuUsage: '42%',
      memoryUsage: '3.9 GB',
      restarts24h: 1
    },
    scorecard: {
      overallGrade: 'Gold',
      scorePercent: 92,
      passedChecks: 11,
      totalChecks: 12,
      lastAudited: '2026-09-27',
      rules: [
        {
          id: 'sec-01',
          name: 'Zero Critical CVEs',
          category: 'security',
          passed: true,
          weight: 15,
          severity: 'critical',
          description: 'Clean dependency tree with npm audit passing.',
          remediationSnippet: 'npm audit --audit-level=high'
        },
        {
          id: 'rel-01',
          name: 'Idempotency Key Enforcement',
          category: 'reliability',
          passed: true,
          weight: 15,
          severity: 'critical',
          description: 'All state-mutating checkout calls require unique X-Idempotency-Key header cached in Redis.',
          remediationSnippet: 'fastify.addHook("preHandler", idempotencyMiddleware)'
        },
        {
          id: 'rel-02',
          name: 'Saga Compensating Transactions',
          category: 'reliability',
          passed: true,
          weight: 10,
          severity: 'major',
          description: 'Rollback handler releases inventory holds if payment execution fails midway.',
          remediationSnippet: 'await sagaCoordinator.compensate(orderId)'
        },
        {
          id: 'doc-02',
          name: 'OpenAPI 3.0 Contract Synchronized',
          category: 'docs',
          passed: false,
          weight: 5,
          severity: 'minor',
          description: 'Swagger schema missing refund callback endpoint payload definitions.',
          remediationSnippet: 'Run: npm run openapi:generate to sync schemas/refund.ts into openapi.yaml'
        },
        {
          id: 'obs-01',
          name: 'OpenTelemetry Distributed Tracing',
          category: 'observability',
          passed: true,
          weight: 10,
          severity: 'major',
          description: 'OpenTelemetry node auto-instrumentation loaded via --require flag.',
          remediationSnippet: 'node --require ./instrumentation.js dist/server.js'
        }
      ]
    },
    deployments: [
      {
        id: 'dep-840',
        version: 'v3.8.1',
        environment: 'production',
        deployedAt: '2026-09-25 18:30 UTC',
        deployedBy: 'sarah.chen',
        commitHash: '4f92c10',
        commitMessage: 'fix: prevent double charge on timeout retry',
        status: 'healthy'
      }
    ],
    openApiSpec: {
      version: '3.0.3',
      title: 'Checkout Orchestration API',
      description: 'Distributed checkout saga transaction coordinator.',
      baseUrl: 'https://checkout.internal.corp/api',
      endpoints: [
        {
          method: 'POST',
          path: '/v2/checkout/initiate',
          summary: 'Initiate Checkout Saga',
          description: 'Validates basket, locks inventory items for 10 minutes, and calculates taxes.',
          authRequired: true,
          requestBody: {
            contentType: 'application/json',
            example: {
              customer_id: 'usr_881923',
              items: [{ sku: 'SKU-7721', qty: 2, unit_price_cents: 4999 }],
              shipping_address_id: 'addr_9011'
            }
          },
          responses: [
            {
              status: 201,
              description: 'Checkout session created',
              example: {
                checkout_id: 'chk_991823a8b',
                total_cents: 9998,
                tax_cents: 800,
                expires_at: '2026-09-29T10:15:00Z',
                status: 'AWAITING_PAYMENT'
              }
            }
          ]
        },
        {
          method: 'POST',
          path: '/v2/checkout/{id}/confirm',
          summary: 'Confirm & Finalize Payment',
          description: 'Executes charge on billing-engine and dispatches order confirmation event.',
          authRequired: true,
          responses: [
            {
              status: 200,
              description: 'Order confirmed successfully',
              example: {
                order_id: 'ord_2026_09918',
                status: 'PAID',
                tracking_number: 'TRK-9812401'
              }
            }
          ]
        }
      ]
    },
    techDocs: [
      {
        id: 'saga-design',
        title: 'Distributed Saga Pattern',
        content: `### Checkout Distributed Saga

The checkout process uses an orchestrated saga to avoid distributed two-phase commit locks.

\`\`\`
1. [ Customer initiates ]
2. [ Lock Inventory ] ──▶ Success?
   ├── YES ──▶ [ Run Fraud Score ] ──▶ [ Capture Payment ]
   └── NO  ──▶ [ Release Holds & Notify User ]
\`\`\`
`
      }
    ]
  },
  {
    id: 'billing-engine',
    name: 'billing-engine',
    description: 'PCI-DSS compliant payment processing engine connecting Stripe, Adyen, and ACH banking rails.',
    type: 'service',
    lifecycle: 'production',
    ownerTeam: 'Checkout & Payments',
    tier: 'Tier 1 (Mission Critical)',
    language: 'Go',
    framework: 'Go stdlib / Chi Router',
    repository: 'github.com/acme/billing-engine',
    runbookUrl: 'https://runbooks.corp.internal/billing-engine',
    slackChannel: '#payments-reliability',
    createdAt: '2023-11-04',
    updatedAt: '2026-09-27',
    dependencies: {
      upstream: ['checkout-orchestrator'],
      downstream: ['notification-dispatcher', 'fraud-risk-evaluator'],
      databases: ['CockroachDB (Multi-Region Ledger)', 'Vault (Tokenization HSM)'],
      queues: ['Kafka: payments.settled.v1', 'Kafka: payment.chargeback.v1']
    },
    metrics: {
      uptime: 99.999,
      deployFrequency: '1.2 / day',
      leadTimeHours: 2.1,
      changeFailureRate: 0.2,
      mttrMinutes: 5,
      p99LatencyMs: 120,
      weeklyRequests: '28M',
      errorRate: 0.001
    },
    tags: ['pci-dss', 'payments', 'vault', 'fintech', 'tier-1'],
    kubernetes: {
      cluster: 'prod-pci-us-east4-gke',
      namespace: 'payments-isolated',
      replicas: 10,
      cpuUsage: '22%',
      memoryUsage: '2.4 GB',
      restarts24h: 0
    },
    scorecard: {
      overallGrade: 'Platinum',
      scorePercent: 100,
      passedChecks: 12,
      totalChecks: 12,
      lastAudited: '2026-09-28',
      rules: [
        {
          id: 'pci-01',
          name: 'PCI-DSS Hardware Tokenization Compliance',
          category: 'security',
          passed: true,
          weight: 20,
          severity: 'critical',
          description: 'No unencrypted primary account numbers (PAN) touch application RAM; zero local storage.',
          remediationSnippet: 'All PANs must route directly through HashiCorp Vault transit secrets engine.'
        },
        {
          id: 'rel-01',
          name: 'Multi-Region High Availability',
          category: 'reliability',
          passed: true,
          weight: 15,
          severity: 'critical',
          description: 'Deployed across us-east4 and us-west1 with auto-failover in CockroachDB.',
          remediationSnippet: 'crdb demo --nodes 3 --geo-partitioning'
        }
      ]
    },
    deployments: [
      {
        id: 'dep-799',
        version: 'v4.1.0',
        environment: 'production',
        deployedAt: '2026-09-24 11:00 UTC',
        deployedBy: 'security-pipeline',
        commitHash: '8e11a3b',
        commitMessage: 'feat(adyen): enable 3D Secure 2.3 biometric challenge flow',
        status: 'healthy'
      }
    ]
  },
  {
    id: 'fraud-risk-evaluator',
    name: 'fraud-risk-evaluator',
    description: 'Real-time machine learning scoring service inspecting graph topology, IP velocity, and device fingerprints.',
    type: 'service',
    lifecycle: 'production',
    ownerTeam: 'Trust & Safety',
    tier: 'Tier 1 (Mission Critical)',
    language: 'Python',
    framework: 'FastAPI / ONNX Runtime',
    repository: 'github.com/acme/fraud-risk-evaluator',
    runbookUrl: 'https://runbooks.corp.internal/fraud-risk-evaluator',
    slackChannel: '#trust-safety-sre',
    createdAt: '2024-08-14',
    updatedAt: '2026-09-26',
    dependencies: {
      upstream: ['auth-gateway', 'checkout-orchestrator'],
      downstream: ['notification-dispatcher'],
      databases: ['ScyllaDB (Velocity Counters)', 'Neo4j (Entity Graph)'],
      queues: ['Kafka: fraud.alerts.v1']
    },
    metrics: {
      uptime: 99.96,
      deployFrequency: '5.1 / day',
      leadTimeHours: 1.0,
      changeFailureRate: 1.1,
      mttrMinutes: 16,
      p99LatencyMs: 24,
      weeklyRequests: '210M',
      errorRate: 0.009
    },
    tags: ['ml', 'onnx', 'fraud-detection', 'real-time', 'python312'],
    kubernetes: {
      cluster: 'prod-us-east4-gke',
      namespace: 'trust-safety',
      replicas: 16,
      cpuUsage: '58%',
      memoryUsage: '14.2 GB',
      restarts24h: 0
    },
    scorecard: {
      overallGrade: 'Platinum',
      scorePercent: 100,
      passedChecks: 12,
      totalChecks: 12,
      lastAudited: '2026-09-28',
      rules: [
        {
          id: 'ml-01',
          name: 'Model Shadow Evaluation Validated',
          category: 'quality',
          passed: true,
          weight: 15,
          severity: 'major',
          description: 'New ONNX model evaluated against dark traffic for 72 hours before live traffic flip.',
          remediationSnippet: 'python scripts/evaluate_shadow_drift.py --model v2.4.onnx'
        }
      ]
    },
    deployments: [
      {
        id: 'dep-612',
        version: 'v2.4.0-onnx',
        environment: 'production',
        deployedAt: '2026-09-26 16:40 UTC',
        deployedBy: 'elena.rostova',
        commitHash: '0d34fa1',
        commitMessage: 'model: deploy gradient-boosted fraud model v24.1',
        status: 'healthy'
      }
    ]
  },
  {
    id: 'inventory-service',
    name: 'inventory-service',
    description: 'Global warehouse SKU availability, allocation holds, and backorder forecasting.',
    type: 'service',
    lifecycle: 'production',
    ownerTeam: 'Supply Chain & Fulfillment',
    tier: 'Tier 2 (Business Essential)',
    language: 'Java',
    framework: 'Spring Boot 3.3',
    repository: 'github.com/acme/inventory-service',
    runbookUrl: 'https://runbooks.corp.internal/inventory-service',
    slackChannel: '#fulfillment-eng',
    createdAt: '2023-08-19',
    updatedAt: '2026-09-22',
    dependencies: {
      upstream: ['checkout-orchestrator'],
      downstream: ['search-indexer-pipeline'],
      databases: ['PostgreSQL (Warehouse Inventory)', 'Redis (Stock Reservations)'],
      queues: ['Kafka: inventory.depleted.v1']
    },
    metrics: {
      uptime: 99.92,
      deployFrequency: '2.1 / week',
      leadTimeHours: 4.8,
      changeFailureRate: 3.5,
      mttrMinutes: 32,
      p99LatencyMs: 65,
      weeklyRequests: '42M',
      errorRate: 0.04
    },
    tags: ['java', 'spring-boot', 'inventory', 'warehousing'],
    kubernetes: {
      cluster: 'prod-us-east4-gke',
      namespace: 'logistics',
      replicas: 6,
      cpuUsage: '45%',
      memoryUsage: '6.2 GB',
      restarts24h: 2
    },
    scorecard: {
      overallGrade: 'Silver',
      scorePercent: 75,
      passedChecks: 9,
      totalChecks: 12,
      lastAudited: '2026-09-26',
      rules: [
        {
          id: 'sec-01',
          name: 'Zero Critical CVEs',
          category: 'security',
          passed: true,
          weight: 15,
          severity: 'critical',
          description: 'Zero critical CVEs in Maven dependencies.',
          remediationSnippet: './mvnw dependency-check:check'
        },
        {
          id: 'qty-01',
          name: 'Unit Test Coverage >= 80%',
          category: 'quality',
          passed: false,
          weight: 10,
          severity: 'major',
          description: 'Current coverage is 68.2%, below the 80% requirement.',
          remediationSnippet: 'Add unit tests for WarehouseAllocationService.java to hit coverage gate.'
        },
        {
          id: 'obs-02',
          name: 'Structured JSON Logging',
          category: 'observability',
          passed: false,
          weight: 5,
          severity: 'minor',
          description: 'Legacy log4j pattern format still outputs unparsed plaintext in container stdout.',
          remediationSnippet: 'Configure logback-spring.xml to use net.logstash.logback.encoder.LogstashEncoder'
        }
      ]
    },
    deployments: [
      {
        id: 'dep-502',
        version: 'v1.18.4',
        environment: 'production',
        deployedAt: '2026-09-20 08:15 UTC',
        deployedBy: 'marcus.vance',
        commitHash: '3b89012',
        commitMessage: 'fix(reserve): handle concurrent pessimistic lock release',
        status: 'healthy'
      }
    ]
  },
  {
    id: 'notification-dispatcher',
    name: 'notification-dispatcher',
    description: 'High-throughput transactional email, push notification, SMS and webhook gateway.',
    type: 'service',
    lifecycle: 'production',
    ownerTeam: 'Platform Core',
    tier: 'Tier 2 (Business Essential)',
    language: 'Python',
    framework: 'FastAPI / Celery / Redis',
    repository: 'github.com/acme/notification-dispatcher',
    runbookUrl: 'https://runbooks.corp.internal/notification-dispatcher',
    slackChannel: '#core-platform-eng',
    createdAt: '2024-03-01',
    updatedAt: '2026-09-28',
    dependencies: {
      upstream: ['auth-gateway', 'checkout-orchestrator', 'fraud-risk-evaluator'],
      downstream: [],
      databases: ['PostgreSQL (Template DB)', 'Redis (Rate Limiter)'],
      queues: ['Kafka: notifications.inbound', 'RabbitMQ: retry.dlq']
    },
    metrics: {
      uptime: 99.97,
      deployFrequency: '3.6 / day',
      leadTimeHours: 1.5,
      changeFailureRate: 1.0,
      mttrMinutes: 14,
      p99LatencyMs: 35,
      weeklyRequests: '65M',
      errorRate: 0.01
    },
    tags: ['notifications', 'email', 'push-alerts', 'celery', 'webhooks'],
    kubernetes: {
      cluster: 'prod-us-east4-gke',
      namespace: 'core-platform',
      replicas: 8,
      cpuUsage: '31%',
      memoryUsage: '3.1 GB',
      restarts24h: 0
    },
    scorecard: {
      overallGrade: 'Gold',
      scorePercent: 92,
      passedChecks: 11,
      totalChecks: 12,
      lastAudited: '2026-09-28',
      rules: [
        {
          id: 'sec-01',
          name: 'Zero Critical CVEs',
          category: 'security',
          passed: true,
          weight: 15,
          severity: 'critical',
          description: 'Bandit static code analysis and pip-audit passing.',
          remediationSnippet: 'pip-audit -r requirements.txt'
        },
        {
          id: 'doc-01',
          name: 'TechDocs Runbook Updated',
          category: 'docs',
          passed: true,
          weight: 5,
          severity: 'minor',
          description: 'Provider failover (SendGrid to AWS SES) documented and tested.',
          remediationSnippet: 'docs/runbooks/email-provider-failover.md'
        }
      ]
    },
    deployments: [
      {
        id: 'dep-431',
        version: 'v2.9.0',
        environment: 'production',
        deployedAt: '2026-09-27 19:10 UTC',
        deployedBy: 'devops-bot',
        commitHash: '9a34bc1',
        commitMessage: 'feat: add APNs HTTP/2 certificate autorenewal',
        status: 'healthy'
      }
    ]
  },
  {
    id: 'customer-web-portal',
    name: 'customer-web-portal',
    description: 'Next.js customer-facing storefront and account dashboard with server-side edge rendering.',
    type: 'service',
    lifecycle: 'production',
    ownerTeam: 'Growth & Frontend',
    tier: 'Tier 2 (Business Essential)',
    language: 'TypeScript / Node.js',
    framework: 'Next.js 15 / React 19',
    repository: 'github.com/acme/customer-web-portal',
    runbookUrl: 'https://runbooks.corp.internal/customer-web-portal',
    slackChannel: '#web-storefront',
    createdAt: '2024-06-12',
    updatedAt: '2026-09-28',
    dependencies: {
      upstream: ['edge-proxy-ingress'],
      downstream: ['auth-gateway', 'checkout-orchestrator'],
      databases: ['Cloudflare KV (Edge Cache)'],
      queues: []
    },
    metrics: {
      uptime: 99.98,
      deployFrequency: '8.2 / day',
      leadTimeHours: 0.6,
      changeFailureRate: 1.2,
      mttrMinutes: 10,
      p99LatencyMs: 95,
      weeklyRequests: '185M',
      errorRate: 0.02
    },
    tags: ['frontend', 'nextjs', 'react', 'edge', 'storefront'],
    kubernetes: {
      cluster: 'prod-us-east4-gke',
      namespace: 'web-frontends',
      replicas: 14,
      cpuUsage: '28%',
      memoryUsage: '4.2 GB',
      restarts24h: 0
    },
    scorecard: {
      overallGrade: 'Gold',
      scorePercent: 92,
      passedChecks: 11,
      totalChecks: 12,
      lastAudited: '2026-09-27',
      rules: [
        {
          id: 'sec-01',
          name: 'CSP & Security Headers Configured',
          category: 'security',
          passed: true,
          weight: 15,
          severity: 'critical',
          description: 'Strict Content-Security-Policy with nonce-based script loading.',
          remediationSnippet: 'next.config.js headers() configuration'
        },
        {
          id: 'qty-01',
          name: 'Core Web Vitals Pass Rate > 95%',
          category: 'quality',
          passed: true,
          weight: 10,
          severity: 'major',
          description: 'LCP < 1.2s, INP < 150ms, CLS < 0.05 on real Chrome user metrics.',
          remediationSnippet: 'Check SpeedCurve dashboard for weekly percentiles'
        }
      ]
    },
    deployments: [
      {
        id: 'dep-991',
        version: 'v4.8.2',
        environment: 'production',
        deployedAt: '2026-09-28 15:45 UTC',
        deployedBy: 'amara.okafor',
        commitHash: '2b771df',
        commitMessage: 'perf: bundle split third-party analytics scripts',
        status: 'healthy'
      }
    ]
  },
  {
    id: 'search-indexer-pipeline',
    name: 'search-indexer-pipeline',
    description: 'Extracts catalog mutations, transforms documents, and streams bulk indexing into Elasticsearch / OpenSearch cluster.',
    type: 'pipeline',
    lifecycle: 'staging',
    ownerTeam: 'Data Eng & Search',
    tier: 'Tier 3 (Supporting)',
    language: 'Python',
    framework: 'Faust / Kafka Streams',
    repository: 'github.com/acme/search-indexer-pipeline',
    runbookUrl: 'https://runbooks.corp.internal/search-indexer',
    slackChannel: '#search-infra',
    createdAt: '2025-01-20',
    updatedAt: '2026-09-18',
    dependencies: {
      upstream: ['inventory-service'],
      downstream: [],
      databases: ['OpenSearch Cluster (Search Engine)'],
      queues: ['Kafka: catalog.mutations.v2']
    },
    metrics: {
      uptime: 99.85,
      deployFrequency: '1.0 / week',
      leadTimeHours: 6.2,
      changeFailureRate: 5.8,
      mttrMinutes: 45,
      p99LatencyMs: 310,
      weeklyRequests: '14M',
      errorRate: 0.12
    },
    tags: ['opensearch', 'streaming', 'data-pipeline', 'kafka'],
    kubernetes: {
      cluster: 'prod-us-east4-gke',
      namespace: 'data-pipelines',
      replicas: 4,
      cpuUsage: '64%',
      memoryUsage: '8.4 GB',
      restarts24h: 3
    },
    scorecard: {
      overallGrade: 'Bronze',
      scorePercent: 58,
      passedChecks: 7,
      totalChecks: 12,
      lastAudited: '2026-09-24',
      rules: [
        {
          id: 'sec-01',
          name: 'Zero Critical CVEs',
          category: 'security',
          passed: true,
          weight: 15,
          severity: 'critical',
          description: 'No critical CVEs.',
          remediationSnippet: 'pip-audit'
        },
        {
          id: 'rel-01',
          name: 'Dead Letter Queue (DLQ) Configured',
          category: 'reliability',
          passed: false,
          weight: 15,
          severity: 'critical',
          description: 'Poison pill messages cause worker thread stalls instead of routing to DLQ.',
          remediationSnippet: 'Add try/except to indexer.py routing failed schema payload to Kafka DLQ.'
        },
        {
          id: 'obs-01',
          name: 'Consumer Lag Metric Exported',
          category: 'observability',
          passed: false,
          weight: 10,
          severity: 'major',
          description: 'Prometheus exporter missing kafka_consumergroup_lag metric.',
          remediationSnippet: 'Deploy kafka-lag-exporter helm chart to namespace data-pipelines.'
        }
      ]
    },
    deployments: [
      {
        id: 'dep-211',
        version: 'v0.9.1-beta',
        environment: 'staging',
        deployedAt: '2026-09-18 10:20 UTC',
        deployedBy: 'dmitri.sokolov',
        commitHash: '5e019ab',
        commitMessage: 'feat(opensearch): implement bulk vector embedding indexing',
        status: 'healthy'
      }
    ]
  },
  {
    id: 'edge-proxy-ingress',
    name: 'edge-proxy-ingress',
    description: 'Envoy-based edge gateway handling TLS termination, rate limiting, and zero-trust mutual auth routing.',
    type: 'infra',
    lifecycle: 'production',
    ownerTeam: 'Platform Core',
    tier: 'Tier 1 (Mission Critical)',
    language: 'Go',
    framework: 'Envoy Proxy v1.31 / xDS Control Plane',
    repository: 'github.com/acme/edge-proxy-ingress',
    runbookUrl: 'https://runbooks.corp.internal/edge-proxy',
    slackChannel: '#edge-networking-core',
    createdAt: '2023-05-11',
    updatedAt: '2026-09-29',
    dependencies: {
      upstream: [],
      downstream: ['auth-gateway', 'customer-web-portal', 'checkout-orchestrator'],
      databases: ['Redis (Global Rate Limiter)'],
      queues: []
    },
    metrics: {
      uptime: 99.999,
      deployFrequency: '0.8 / day',
      leadTimeHours: 1.1,
      changeFailureRate: 0.1,
      mttrMinutes: 4,
      p99LatencyMs: 6,
      weeklyRequests: '890M',
      errorRate: 0.001
    },
    tags: ['envoy', 'networking', 'edge', 'tls', 'rate-limiting', 'tier-1'],
    kubernetes: {
      cluster: 'prod-us-east4-gke',
      namespace: 'ingress-system',
      replicas: 24,
      cpuUsage: '38%',
      memoryUsage: '6.8 GB',
      restarts24h: 0
    },
    scorecard: {
      overallGrade: 'Platinum',
      scorePercent: 100,
      passedChecks: 12,
      totalChecks: 12,
      lastAudited: '2026-09-29',
      rules: [
        {
          id: 'sec-01',
          name: 'Zero Critical CVEs',
          category: 'security',
          passed: true,
          weight: 15,
          severity: 'critical',
          description: 'All Envoy patches and BoringSSL libraries up to date.',
          remediationSnippet: 'Rebuild container with envoyproxy/envoy:v1.31-latest'
        }
      ]
    },
    deployments: [
      {
        id: 'dep-980',
        version: 'v1.31.2',
        environment: 'production',
        deployedAt: '2026-09-26 04:00 UTC',
        deployedBy: 'network-ops',
        commitHash: '0a8161f',
        commitMessage: 'chore(envoy): bump to 1.31.2 security maintenance release',
        status: 'healthy'
      }
    ]
  }
];
