import React, { useState, useMemo } from 'react';
import { usePortal } from '../../context/PortalContext';
import { GoldenPathTemplate } from '../../types/template';
import { ScaffolderWizardModal } from './ScaffolderWizardModal';
import {
  Cpu,
  Server,
  Activity,
  Layout,
  Cloud,
  Plus,
  Star,
  Search,
  CheckCircle2,
  ExternalLink,
  Code
} from 'lucide-react';

export const GoldenPathsView: React.FC = () => {
  const { templates, setSelectedTemplate, isScaffolderModalOpen, setIsScaffolderModalOpen } = usePortal();

  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [activeModalTemplate, setActiveModalTemplate] = useState<GoldenPathTemplate | null>(null);

  const categories = [
    { id: 'all', label: 'All Templates' },
    { id: 'Backend Microservice', label: 'Backend Microservices' },
    { id: 'Data & Streaming', label: 'Data & Streaming' },
    { id: 'Frontend Web', label: 'Frontend Apps' },
    { id: 'Cloud Infrastructure', label: 'Cloud Infrastructure' }
  ];

  const filteredTemplates = useMemo(() => {
    return templates.filter((tmpl) => {
      const matchCategory = activeCategory === 'all' || tmpl.category === activeCategory;
      const matchSearch =
        !search ||
        tmpl.name.toLowerCase().includes(search.toLowerCase()) ||
        tmpl.description.toLowerCase().includes(search.toLowerCase()) ||
        tmpl.tags.some((t) => t.toLowerCase().includes(search.toLowerCase())) ||
        tmpl.language.toLowerCase().includes(search.toLowerCase());

      return matchCategory && matchSearch;
    });
  }, [templates, activeCategory, search]);

  const handleLaunchScaffolder = (tmpl: GoldenPathTemplate) => {
    setActiveModalTemplate(tmpl);
    setSelectedTemplate(tmpl);
    setIsScaffolderModalOpen(true);
  };

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Cpu':
        return Cpu;
      case 'Server':
        return Server;
      case 'Activity':
        return Activity;
      case 'Layout':
        return Layout;
      case 'Cloud':
        return Cloud;
      default:
        return Code;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Golden Paths & Software Templates
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Standardized, production-ready boilerplates with pre-configured CI/CD, telemetry, security scanning, and GitOps.
          </p>
        </div>

        <button
          onClick={() => {
            setActiveModalTemplate(templates[0]);
            setIsScaffolderModalOpen(true);
          }}
          className="flex items-center gap-1.5 rounded bg-indigo-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-indigo-500 transition-colors shadow-sm self-start sm:self-auto"
        >
          <Plus className="h-3.5 w-3.5" />
          <span>Launch Scaffolder</span>
        </button>
      </div>

      {/* Filter and Category Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        {/* Category Buttons */}
        <div className="flex flex-wrap gap-1 p-1 bg-slate-900 rounded-lg border border-slate-800">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                activeCategory === cat.id
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative max-w-xs w-full">
          <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search templates..."
            className="w-full rounded border border-slate-800 bg-slate-900/60 pl-8 pr-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTemplates.map((tmpl) => {
          const IconComponent = getIcon(tmpl.iconName);
          return (
            <div
              key={tmpl.id}
              className="flex flex-col justify-between rounded-lg border border-slate-800 bg-slate-900/50 p-5 hover:border-slate-700 transition-colors"
            >
              <div>
                {/* Header info */}
                <div className="flex items-center justify-between text-xs text-slate-500 font-mono mb-2">
                  <span>{tmpl.category}</span>
                  <div className="flex items-center gap-1 text-amber-400">
                    <Star className="h-3 w-3 fill-current" />
                    <span className="text-[11px] font-semibold">{tmpl.stars}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded bg-slate-800 border border-slate-700 text-indigo-400 shrink-0">
                    <IconComponent className="h-4 w-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-slate-100">{tmpl.name}</h3>
                    <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                      {tmpl.language} · {tmpl.version}
                    </div>
                  </div>
                </div>

                <p className="mt-3 text-xs text-slate-400 leading-relaxed">
                  {tmpl.description}
                </p>

                {/* Included Add-ons List */}
                <div className="mt-4 border-t border-slate-800/80 pt-3">
                  <div className="text-[11px] font-medium text-slate-300 mb-2">
                    Batteries Included:
                  </div>
                  <ul className="space-y-1 text-[11px] text-slate-400">
                    {tmpl.includedAddons.slice(0, 3).map((addon, i) => (
                      <li key={i} className="flex items-center gap-1.5">
                        <CheckCircle2 className="h-3 w-3 text-emerald-400 shrink-0" />
                        <span className="truncate">{addon}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="mt-5 border-t border-slate-800 pt-3 flex items-center justify-between">
                <span className="text-[11px] text-slate-500">by {tmpl.author}</span>
                <button
                  onClick={() => handleLaunchScaffolder(tmpl)}
                  className="rounded bg-indigo-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-indigo-500 transition-colors shadow-sm"
                >
                  Choose Template
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Scaffolder Wizard Modal */}
      {isScaffolderModalOpen && (
        <ScaffolderWizardModal
          template={activeModalTemplate}
          onClose={() => setIsScaffolderModalOpen(false)}
        />
      )}
    </div>
  );
};
