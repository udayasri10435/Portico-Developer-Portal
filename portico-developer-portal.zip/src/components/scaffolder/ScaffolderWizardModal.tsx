import React, { useState } from 'react';
import { GoldenPathTemplate, ScaffoldExecutionLog } from '../../types/template';
import { ServiceEntity } from '../../types/catalog';
import { usePortal } from '../../context/PortalContext';
import {
  X,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Terminal,
  Cpu,
  Layers,
  Sparkles,
  ExternalLink,
  Loader2,
  Database,
  Lock,
  GitBranch
} from 'lucide-react';

interface ScaffolderWizardModalProps {
  template: GoldenPathTemplate | null;
  onClose: () => void;
}

export const ScaffolderWizardModal: React.FC<ScaffolderWizardModalProps> = ({ template: initialTemplate, onClose }) => {
  const { templates, addNewService, setSelectedServiceId, setActiveTab } = usePortal();

  // Selected template state
  const [selectedTemplate, setSelectedTemplate] = useState<GoldenPathTemplate>(
    initialTemplate || templates[0]
  );

  const [currentStep, setCurrentStep] = useState<number>(1);
  const [formData, setFormData] = useState<Record<string, any>>({
    serviceName: '',
    description: '',
    ownerTeam: 'Platform Core',
    tier: 'Tier 1 (Mission Critical)',
    databaseAddon: 'postgres',
    enableTracing: true,
    enableVault: true,
    kafkaTopic: 'events.inbound.v1'
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [executionLogs, setExecutionLogs] = useState<ScaffoldExecutionLog[]>([]);
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionFinished, setExecutionFinished] = useState(false);
  const [createdService, setCreatedService] = useState<ServiceEntity | null>(null);

  const handleInputChange = (field: string, val: any) => {
    setFormData((prev) => ({ ...prev, [field]: val }));
    if (formErrors[field]) {
      setFormErrors((prev) => {
        const copy = { ...prev };
        delete copy[field];
        return copy;
      });
    }
  };

  const validateStep1 = () => {
    const errors: Record<string, string> = {};
    if (!formData.serviceName || !formData.serviceName.trim()) {
      errors.serviceName = 'Service name is required';
    } else if (!/^[a-z0-9-]+$/.test(formData.serviceName)) {
      errors.serviceName = 'Must be lowercase alphanumeric kebab-case (e.g. payout-service)';
    }

    if (!formData.description || !formData.description.trim()) {
      errors.description = 'Description is required';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleNext = () => {
    if (currentStep === 1) {
      if (!validateStep1()) return;
      setCurrentStep(2);
    } else if (currentStep === 2) {
      setCurrentStep(3);
    } else if (currentStep === 3) {
      runScaffoldExecution();
    }
  };

  const runScaffoldExecution = () => {
    setCurrentStep(4);
    setIsExecuting(true);
    setExecutionLogs([]);
    setExecutionFinished(false);

    const steps = selectedTemplate.executionSteps;
    const now = () => new Date().toLocaleTimeString();

    // Sequentially dispatch simulated logs
    steps.forEach((step, index) => {
      setTimeout(() => {
        setExecutionLogs((prev) => [
          ...prev,
          {
            timestamp: now(),
            level: 'info',
            message: `[${index + 1}/${steps.length}] ${step.title}: ${step.description}`,
            stepId: step.id
          }
        ]);

        if (index === steps.length - 1) {
          setTimeout(() => {
            setExecutionLogs((prev) => [
              ...prev,
              {
                timestamp: now(),
                level: 'success',
                message: `✔ Golden Path Scaffold Complete! Component '${formData.serviceName}' registered in Portico IDP.`
              }
            ]);
            setIsExecuting(false);
            setExecutionFinished(true);

            // Construct new ServiceEntity and inject into Catalog
            const newEntity: ServiceEntity = {
              id: formData.serviceName.toLowerCase(),
              name: formData.serviceName.toLowerCase(),
              description: formData.description,
              type: selectedTemplate.category === 'Frontend Web' ? 'service' : selectedTemplate.category === 'Cloud Infrastructure' ? 'infra' : 'service',
              lifecycle: 'experimental',
              ownerTeam: formData.ownerTeam || 'Platform Core',
              tier: formData.tier || 'Tier 2 (Business Essential)',
              language: selectedTemplate.language,
              framework: selectedTemplate.framework,
              repository: `github.com/acme/${formData.serviceName.toLowerCase()}`,
              runbookUrl: `https://runbooks.corp.internal/${formData.serviceName.toLowerCase()}`,
              slackChannel: `#${formData.serviceName.toLowerCase()}-alerts`,
              createdAt: new Date().toISOString().split('T')[0],
              updatedAt: new Date().toISOString().split('T')[0],
              dependencies: {
                upstream: ['edge-proxy-ingress'],
                downstream: ['auth-gateway'],
                databases: formData.databaseAddon === 'none' ? [] : [formData.databaseAddon === 'postgres' ? 'PostgreSQL 16' : formData.databaseAddon === 'redis' ? 'Redis 7.2' : 'PostgreSQL + Redis'],
                queues: formData.kafkaTopic ? [`Kafka: ${formData.kafkaTopic}`] : []
              },
              metrics: {
                uptime: 100.0,
                deployFrequency: '0.0 / day',
                leadTimeHours: 0.1,
                changeFailureRate: 0.0,
                mttrMinutes: 0,
                p99LatencyMs: 18,
                weeklyRequests: '0',
                errorRate: 0.0
              },
              tags: [selectedTemplate.language.toLowerCase(), 'golden-path-scaffold', 'new-service'],
              kubernetes: {
                cluster: 'prod-us-east4-gke',
                namespace: 'dev-workloads',
                replicas: 2,
                cpuUsage: '4%',
                memoryUsage: '120 MB',
                restarts24h: 0
              },
              scorecard: {
                overallGrade: 'Gold',
                scorePercent: 92,
                passedChecks: 11,
                totalChecks: 12,
                lastAudited: 'Just now',
                rules: [
                  {
                    id: 'tmpl-sec',
                    name: 'Vetted Container Distroless Base',
                    category: 'security',
                    passed: true,
                    weight: 15,
                    severity: 'critical',
                    description: 'Scaffolded with official distroless static base.',
                    remediationSnippet: 'Already compliant via golden path template.'
                  },
                  {
                    id: 'tmpl-rel',
                    name: 'Standard Probes & Graceful Shutdown',
                    category: 'reliability',
                    passed: true,
                    weight: 15,
                    severity: 'critical',
                    description: '/healthz and /ready endpoints configured.',
                    remediationSnippet: 'Configured in app startup.'
                  },
                  {
                    id: 'tmpl-obs',
                    name: 'OpenTelemetry Pre-Wired',
                    category: 'observability',
                    passed: !!formData.enableTracing,
                    weight: 10,
                    severity: 'major',
                    description: 'Tracing middleware configured.',
                    remediationSnippet: 'Inject OpenTelemetry SDK.'
                  },
                  {
                    id: 'tmpl-doc',
                    name: 'catalog-info.yaml & TechDocs Boilerplate',
                    category: 'docs',
                    passed: true,
                    weight: 10,
                    severity: 'minor',
                    description: 'catalog-info.yaml committed to main.',
                    remediationSnippet: 'Synchronized with IDP.'
                  }
                ]
              },
              deployments: [
                {
                  id: `dep-${Date.now()}`,
                  version: 'v0.1.0-scaffold',
                  environment: 'canary',
                  deployedAt: 'Just now',
                  deployedBy: 'Portico Scaffolder Bot',
                  commitHash: 'a1b2c3d',
                  commitMessage: `chore(scaffold): initialize ${formData.serviceName} from ${selectedTemplate.name}`,
                  status: 'healthy'
                }
              ],
              openApiSpec: {
                version: '3.0.3',
                title: `${formData.serviceName} Service API`,
                description: formData.description,
                baseUrl: `https://${formData.serviceName.toLowerCase()}.internal.corp/v1`,
                endpoints: [
                  {
                    method: 'GET',
                    path: '/healthz',
                    summary: 'Liveness Probe',
                    description: 'Returns HTTP 200 when container is healthy.',
                    authRequired: false,
                    responses: [{ status: 200, description: 'Service Healthy', example: { status: 'healthy', uptime_seconds: 4 } }]
                  },
                  {
                    method: 'GET',
                    path: '/v1/items',
                    summary: 'List Resources',
                    description: 'Retrieves paginated list of items.',
                    authRequired: true,
                    responses: [{ status: 200, description: 'Success', example: { items: [], total: 0 } }]
                  }
                ]
              },
              techDocs: [
                {
                  id: 'readme',
                  title: 'Getting Started Runbook',
                  content: `### Welcome to ${formData.serviceName}\n\nThis service was scaffolded using Portico IDP Golden Path: **${selectedTemplate.name}**.\n\n#### Local Development:\n\`\`\`bash\ngit clone git@github.com:acme/${formData.serviceName}.git\ncd ${formData.serviceName}\nmake run\n\`\`\`\n\n#### CI/CD Pipeline:\nCommits to \`main\` automatically build multi-stage Docker images and trigger ArgoCD sync.`
                }
              ]
            };

            addNewService(newEntity);
            setCreatedService(newEntity);
          }, 800);
        }
      }, (index + 1) * 900);
    });
  };

  const handleFinishAndOpenService = () => {
    if (createdService) {
      setSelectedServiceId(createdService.id);
      setActiveTab('catalog');
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div
        className="w-full max-w-3xl rounded-lg border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4 bg-slate-950/60">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-indigo-400">
                Golden Path Scaffolder
              </span>
              <span className="text-xs text-slate-500">·</span>
              <span className="text-xs text-slate-400 font-mono">Step {currentStep} of 4</span>
            </div>
            <h2 className="text-base font-semibold text-slate-100 mt-0.5">
              {currentStep === 1 && 'Choose Template & Identity'}
              {currentStep === 2 && 'Architecture & Infrastructure Add-ons'}
              {currentStep === 3 && 'Review Parameters & Dry Run'}
              {currentStep === 4 && 'Scaffold Execution'}
            </h2>
          </div>
          <button
            onClick={onClose}
            disabled={isExecuting}
            className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition-colors disabled:opacity-30"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Wizard Body */}
        <div className="p-6 overflow-y-auto flex-1">
          {/* STEP 1: TEMPLATE & IDENTITY */}
          {currentStep === 1 && (
            <div className="space-y-5">
              {/* Template Selector Dropdown / Pills */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-2">
                  Select Golden Path Template
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {templates.map((tmpl) => (
                    <button
                      key={tmpl.id}
                      type="button"
                      onClick={() => setSelectedTemplate(tmpl)}
                      className={`flex flex-col text-left p-3 rounded border transition-colors ${
                        selectedTemplate.id === tmpl.id
                          ? 'border-indigo-500 bg-slate-800/80 text-white shadow-sm'
                          : 'border-slate-800 bg-slate-950/40 text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-slate-200">{tmpl.name}</span>
                        <span className="text-[10px] text-indigo-400 font-mono">{tmpl.version}</span>
                      </div>
                      <span className="text-[11px] text-slate-500 mt-1 line-clamp-1">{tmpl.description}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Service Identity Inputs */}
              <div className="space-y-3.5 pt-2 border-t border-slate-800">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Component / Service Name <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.serviceName}
                    onChange={(e) => handleInputChange('serviceName', e.target.value)}
                    placeholder="e.g. payment-reconciliation-worker"
                    className="w-full rounded border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:outline-none font-mono"
                  />
                  {formErrors.serviceName ? (
                    <p className="mt-1 text-[11px] text-rose-400">{formErrors.serviceName}</p>
                  ) : (
                    <p className="mt-1 text-[11px] text-slate-500">
                      Lowercase kebab-case. This will be the GitHub repository name and catalog ID.
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Short Description <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    placeholder="e.g. Reconciles settlement files from payment gateways every morning"
                    className="w-full rounded border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:outline-none"
                  />
                  {formErrors.description && (
                    <p className="mt-1 text-[11px] text-rose-400">{formErrors.description}</p>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Owning Team <span className="text-rose-400">*</span>
                    </label>
                    <select
                      value={formData.ownerTeam}
                      onChange={(e) => handleInputChange('ownerTeam', e.target.value)}
                      className="w-full rounded border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-200 focus:border-indigo-500 focus:outline-none"
                    >
                      <option value="Platform Core">Platform Core</option>
                      <option value="Identity & Access">Identity & Access</option>
                      <option value="Checkout & Payments">Checkout & Payments</option>
                      <option value="Supply Chain & Fulfillment">Supply Chain & Fulfillment</option>
                      <option value="Data Eng & Search">Data Eng & Search</option>
                      <option value="Growth & Frontend">Growth & Frontend</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Criticality Tier
                    </label>
                    <select
                      value={formData.tier}
                      onChange={(e) => handleInputChange('tier', e.target.value)}
                      className="w-full rounded border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-200 focus:border-indigo-500 focus:outline-none"
                    >
                      <option value="Tier 1 (Mission Critical)">Tier 1 (Mission Critical - 99.99%)</option>
                      <option value="Tier 2 (Business Essential)">Tier 2 (Business Essential - 99.9%)</option>
                      <option value="Tier 3 (Supporting)">Tier 3 (Internal Supporting - 99.5%)</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: ARCHITECTURE & ADD-ONS */}
          {currentStep === 2 && (
            <div className="space-y-4">
              <p className="text-xs text-slate-400">
                Portico automates infrastructure provisioning and secrets binding during repository generation.
              </p>

              {/* Database Provisioning */}
              <div className="rounded border border-slate-800 bg-slate-950/40 p-4 space-y-2">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
                  <Database className="h-4 w-4 text-indigo-400" />
                  <span>Managed Database Provisioning</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Automates Cloud SQL provisioning with scale-to-zero in non-prod and dedicated instance in prod.
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                  {[
                    { id: 'postgres', label: 'PostgreSQL 16' },
                    { id: 'redis', label: 'Redis Cache' },
                    { id: 'both', label: 'Postgres + Redis' },
                    { id: 'none', label: 'None (Stateless)' }
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handleInputChange('databaseAddon', opt.id)}
                      className={`py-2 px-3 rounded border text-xs font-medium transition-colors ${
                        formData.databaseAddon === opt.id
                          ? 'border-indigo-500 bg-slate-800 text-white'
                          : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Secrets & Security Binding */}
              <div className="rounded border border-slate-800 bg-slate-950/40 p-4 space-y-3">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
                  <Lock className="h-4 w-4 text-emerald-400" />
                  <span>Zero-Trust Security & Vault Leases</span>
                </div>
                <div className="space-y-2 text-xs">
                  <label className="flex items-center gap-2.5 cursor-pointer text-slate-300">
                    <input
                      type="checkbox"
                      checked={formData.enableVault}
                      onChange={(e) => handleInputChange('enableVault', e.target.checked)}
                      className="rounded border-slate-700 bg-slate-950 text-indigo-600 focus:ring-0"
                    />
                    <span>Provision HashiCorp Vault dynamic secret lease role and sidecar agent</span>
                  </label>
                  <label className="flex items-center gap-2.5 cursor-pointer text-slate-300">
                    <input
                      type="checkbox"
                      checked={formData.enableTracing}
                      onChange={(e) => handleInputChange('enableTracing', e.target.checked)}
                      className="rounded border-slate-700 bg-slate-950 text-indigo-600 focus:ring-0"
                    />
                    <span>Inject OpenTelemetry W3C distributed trace context exporter</span>
                  </label>
                </div>
              </div>

              {/* Streaming Kafka topic if applicable */}
              <div className="rounded border border-slate-800 bg-slate-950/40 p-4 space-y-2">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
                  <GitBranch className="h-4 w-4 text-amber-400" />
                  <span>Kafka Event Bus Binding</span>
                </div>
                <input
                  type="text"
                  value={formData.kafkaTopic}
                  onChange={(e) => handleInputChange('kafkaTopic', e.target.value)}
                  placeholder="e.g. orders.processed.v1"
                  className="w-full rounded border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:outline-none font-mono"
                />
              </div>
            </div>
          )}

          {/* STEP 3: REVIEW DRY RUN */}
          {currentStep === 3 && (
            <div className="space-y-4">
              <div className="rounded border border-slate-800 bg-slate-950/50 p-4">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
                  Scaffold Execution Plan Summary
                </h3>
                <dl className="grid grid-cols-2 gap-y-2 text-xs">
                  <dt className="text-slate-500">Golden Path:</dt>
                  <dd className="font-semibold text-slate-200">{selectedTemplate.name}</dd>

                  <dt className="text-slate-500">Service Name:</dt>
                  <dd className="font-mono text-indigo-400">{formData.serviceName}</dd>

                  <dt className="text-slate-500">Owning Squad:</dt>
                  <dd className="text-slate-200">{formData.ownerTeam}</dd>

                  <dt className="text-slate-500">Target Repository:</dt>
                  <dd className="font-mono text-slate-300">github.com/acme/{formData.serviceName}</dd>

                  <dt className="text-slate-500">Database Add-on:</dt>
                  <dd className="text-slate-200 capitalize">{formData.databaseAddon}</dd>

                  <dt className="text-slate-500">Tracing & Vault:</dt>
                  <dd className="text-emerald-400">
                    {formData.enableTracing ? 'OpenTelemetry Enabled' : 'Disabled'} ·{' '}
                    {formData.enableVault ? 'Vault Enabled' : 'Disabled'}
                  </dd>
                </dl>
              </div>

              <div>
                <h4 className="text-xs font-semibold text-slate-300 mb-2">Automated Tasks ({selectedTemplate.executionSteps.length} steps):</h4>
                <div className="space-y-1.5">
                  {selectedTemplate.executionSteps.map((step, idx) => (
                    <div
                      key={step.id}
                      className="flex items-center justify-between rounded border border-slate-800/80 bg-slate-950/30 p-2 text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-slate-500">0{idx + 1}.</span>
                        <span className="font-medium text-slate-300">{step.title}</span>
                      </div>
                      <span className="text-[11px] text-slate-500 font-mono">{step.action}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: EXECUTION PROGRESS & TERMINAL */}
          {currentStep === 4 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {isExecuting ? (
                    <Loader2 className="h-4 w-4 animate-spin text-indigo-400" />
                  ) : (
                    <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  )}
                  <span className="text-xs font-semibold text-slate-200">
                    {isExecuting ? 'Scaffolding Golden Path Service...' : 'Service Successfully Scaffolded!'}
                  </span>
                </div>
                <span className="text-[11px] font-mono text-slate-500">
                  {executionLogs.length} logs emitted
                </span>
              </div>

              {/* Streaming Terminal Output */}
              <div className="rounded border border-slate-800 bg-slate-950 p-3.5 font-mono text-xs space-y-1.5 h-64 overflow-y-auto">
                {executionLogs.map((log, index) => (
                  <div key={index} className="flex items-start gap-2">
                    <span className="text-slate-600 select-none text-[10px] pt-0.5">
                      {log.timestamp}
                    </span>
                    <span
                      className={`break-all leading-relaxed ${
                        log.level === 'success'
                          ? 'text-emerald-400 font-semibold'
                          : log.level === 'warn'
                          ? 'text-amber-400'
                          : 'text-slate-300'
                      }`}
                    >
                      {log.message}
                    </span>
                  </div>
                ))}
                {isExecuting && (
                  <div className="flex items-center gap-1.5 text-indigo-400 text-xs animate-pulse">
                    <span>▶ Running automated runner step...</span>
                  </div>
                )}
              </div>

              {/* Post-execution Action Buttons */}
              {executionFinished && (
                <div className="rounded border border-emerald-900/60 bg-emerald-950/30 p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div>
                    <h4 className="text-xs font-semibold text-emerald-300">
                      Your new service is ready and cataloged!
                    </h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      All golden path guardrails, CI/CD pipelines, and health probes are active.
                    </p>
                  </div>
                  <button
                    onClick={handleFinishAndOpenService}
                    className="flex items-center gap-1.5 rounded bg-emerald-600 px-4 py-2 text-xs font-medium text-white hover:bg-emerald-500 transition-colors whitespace-nowrap"
                  >
                    <span>View Service in Catalog</span>
                    <ArrowRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer Navigation */}
        {currentStep < 4 && (
          <div className="flex items-center justify-between border-t border-slate-800 bg-slate-950/60 px-6 py-3.5">
            {currentStep > 1 ? (
              <button
                type="button"
                onClick={() => setCurrentStep((prev) => prev - 1)}
                className="flex items-center gap-1 rounded px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 transition-colors"
              >
                <ArrowLeft className="h-3.5 w-3.5" />
                <span>Back</span>
              </button>
            ) : (
              <div />
            )}

            <button
              type="button"
              onClick={handleNext}
              className="flex items-center gap-1.5 rounded bg-indigo-600 px-4 py-1.5 text-xs font-medium text-white hover:bg-indigo-500 transition-colors shadow-sm"
            >
              <span>{currentStep === 3 ? 'Execute Scaffold' : 'Next Step'}</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
