import React, { useState } from 'react';
import { ServiceEntity } from '../../types/catalog';
import { usePortal } from '../../context/PortalContext';
import {
  X,
  ExternalLink,
  ShieldCheck,
  FileText,
  Code2,
  GitBranch,
  Layers,
  Terminal,
  Clock,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw,
  Copy,
  Check
} from 'lucide-react';

interface ServiceDetailModalProps {
  service: ServiceEntity;
  onClose: () => void;
}

export const ServiceDetailModal: React.FC<ServiceDetailModalProps> = ({ service, onClose }) => {
  const { setAuditDrawerServiceId, setSelectedServiceId } = usePortal();
  const [activeTab, setActiveTab] = useState<'overview' | 'scorecard' | 'api' | 'docs' | 'deployments' | 'k8s'>('overview');
  const [selectedEndpointIndex, setSelectedEndpointIndex] = useState(0);
  const [apiTestResponse, setApiTestResponse] = useState<any | null>(null);
  const [isTestingApi, setIsTestingApi] = useState(false);
  const [copiedSnippet, setCopiedSnippet] = useState(false);

  const endpoints = service.openApiSpec?.endpoints || [];
  const currentEndpoint = endpoints[selectedEndpointIndex];

  const handleTestApi = () => {
    setIsTestingApi(true);
    setApiTestResponse(null);
    setTimeout(() => {
      setIsTestingApi(false);
      setApiTestResponse({
        status: currentEndpoint?.responses[0]?.status || 200,
        latencyMs: Math.floor(Math.random() * 25) + 12,
        headers: {
          'content-type': 'application/json; charset=utf-8',
          'x-trace-id': `trc_${Math.random().toString(36).substring(2, 10)}`,
          'x-ratelimit-remaining': '984'
        },
        body: currentEndpoint?.responses[0]?.example || { status: 'ok', timestamp: new Date().toISOString() }
      });
    }, 600);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSnippet(true);
    setTimeout(() => setCopiedSnippet(false), 2000);
  };

  const gradeColors: Record<string, string> = {
    Platinum: 'text-emerald-400 bg-emerald-950/50 border-emerald-800',
    Gold: 'text-amber-400 bg-amber-950/50 border-amber-800',
    Silver: 'text-slate-300 bg-slate-800/60 border-slate-700',
    Bronze: 'text-amber-600 bg-amber-950/30 border-amber-900',
    'Needs Review': 'text-rose-400 bg-rose-950/50 border-rose-800'
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-3 sm:p-6 overflow-y-auto">
      <div
        className="w-full max-w-5xl rounded-lg border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between border-b border-slate-800 px-5 py-4 bg-slate-950/50">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded bg-slate-800 border border-slate-700 text-slate-200 font-mono text-sm font-semibold">
              {service.name.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-semibold text-slate-100">{service.name}</h2>
                <span className={`text-[11px] font-medium px-2 py-0.5 rounded border ${gradeColors[service.scorecard.overallGrade] || 'text-slate-400'}`}>
                  {service.scorecard.overallGrade} ({service.scorecard.scorePercent}%)
                </span>
                <span className="text-[11px] text-slate-400">·</span>
                <span className="text-[11px] text-slate-400">{service.tier}</span>
              </div>
              <p className="text-xs text-slate-400 truncate max-w-xl">{service.description}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setAuditDrawerServiceId(service.id);
              }}
              className="flex items-center gap-1.5 rounded border border-slate-700 bg-slate-800 px-2.5 py-1.5 text-xs text-slate-200 hover:bg-slate-700 transition-colors"
            >
              <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
              <span>Audit Checks</span>
            </button>
            <button
              onClick={onClose}
              className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 px-5 bg-slate-950/30 overflow-x-auto">
          {[
            { id: 'overview', label: 'Overview', icon: Layers },
            { id: 'scorecard', label: `Scorecard (${service.scorecard.passedChecks}/${service.scorecard.totalChecks})`, icon: ShieldCheck },
            { id: 'api', label: `API Specs (${endpoints.length})`, icon: Code2 },
            { id: 'docs', label: 'TechDocs', icon: FileText },
            { id: 'deployments', label: 'Deployments', icon: GitBranch },
            { id: 'k8s', label: 'Kubernetes Pods', icon: Activity }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 py-3 px-3 text-xs font-medium border-b-2 transition-colors whitespace-nowrap ${
                  isActive
                    ? 'border-indigo-500 text-white'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content Body */}
        <div className="p-6 overflow-y-auto flex-1">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Essential Metadata Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="rounded border border-slate-800 bg-slate-950/40 p-3">
                  <div className="text-[11px] text-slate-500">Owning Team</div>
                  <div className="text-xs font-medium text-slate-200 mt-1">{service.ownerTeam}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">{service.slackChannel}</div>
                </div>
                <div className="rounded border border-slate-800 bg-slate-950/40 p-3">
                  <div className="text-[11px] text-slate-500">Stack & Language</div>
                  <div className="text-xs font-medium text-slate-200 mt-1">{service.language}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">{service.framework}</div>
                </div>
                <div className="rounded border border-slate-800 bg-slate-950/40 p-3">
                  <div className="text-[11px] text-slate-500">Lifecycle & Tier</div>
                  <div className="text-xs font-medium text-slate-200 mt-1 capitalize">{service.lifecycle}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">{service.tier.split(' ')[0]}</div>
                </div>
                <div className="rounded border border-slate-800 bg-slate-950/40 p-3">
                  <div className="text-[11px] text-slate-500">Source Repository</div>
                  <div className="text-xs font-medium text-indigo-400 mt-1 truncate">
                    <a href={`https://${service.repository}`} target="_blank" rel="noreferrer" className="hover:underline flex items-center gap-1">
                      <span>{service.repository.replace('github.com/', '')}</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">main branch</div>
                </div>
              </div>

              {/* DORA & Operational Telemetry */}
              <div>
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
                  Operational Health & DORA Metrics
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="rounded border border-slate-800 bg-slate-950/30 p-3">
                    <div className="text-[11px] text-slate-500">Uptime (30d)</div>
                    <div className="text-base font-semibold font-mono text-emerald-400 tabular-nums mt-0.5">
                      {service.metrics.uptime}%
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5">SLA: 99.95%</div>
                  </div>
                  <div className="rounded border border-slate-800 bg-slate-950/30 p-3">
                    <div className="text-[11px] text-slate-500">Deployment Frequency</div>
                    <div className="text-base font-semibold font-mono text-slate-100 tabular-nums mt-0.5">
                      {service.metrics.deployFrequency}
                    </div>
                    <div className="text-[10px] text-emerald-400 mt-0.5">Elite Velocity</div>
                  </div>
                  <div className="rounded border border-slate-800 bg-slate-950/30 p-3">
                    <div className="text-[11px] text-slate-500">Lead Time for Changes</div>
                    <div className="text-base font-semibold font-mono text-slate-100 tabular-nums mt-0.5">
                      {service.metrics.leadTimeHours}h
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5">Commit to Prod</div>
                  </div>
                  <div className="rounded border border-slate-800 bg-slate-950/30 p-3">
                    <div className="text-[11px] text-slate-500">p99 Response Latency</div>
                    <div className="text-base font-semibold font-mono text-slate-100 tabular-nums mt-0.5">
                      {service.metrics.p99LatencyMs}ms
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5">Weekly reqs: {service.metrics.weeklyRequests}</div>
                  </div>
                </div>
              </div>

              {/* System Dependency Graph Breakdown */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="rounded border border-slate-800 bg-slate-950/30 p-4">
                  <div className="text-xs font-semibold text-slate-300 mb-2 flex items-center justify-between">
                    <span>Upstream Callers ({service.dependencies.upstream.length})</span>
                    <span className="text-[10px] text-slate-500">Inbound Traffic</span>
                  </div>
                  {service.dependencies.upstream.length === 0 ? (
                    <div className="text-xs text-slate-500 italic">None (Edge Ingress Gateway)</div>
                  ) : (
                    <div className="flex flex-wrap gap-1.5">
                      {service.dependencies.upstream.map((up) => (
                        <button
                          key={up}
                          onClick={() => setSelectedServiceId(up)}
                          className="rounded border border-slate-700 bg-slate-800 px-2 py-1 text-xs text-slate-300 hover:border-indigo-500 hover:text-white transition-colors"
                        >
                          {up}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div className="rounded border border-slate-800 bg-slate-950/30 p-4">
                  <div className="text-xs font-semibold text-slate-300 mb-2 flex items-center justify-between">
                    <span>Downstream Dependencies ({service.dependencies.downstream.length})</span>
                    <span className="text-[10px] text-slate-500">Outbound RPCs</span>
                  </div>
                  {service.dependencies.downstream.length === 0 ? (
                    <div className="text-xs text-slate-500 italic">No microservice dependencies</div>
                  ) : (
                    <div className="flex flex-wrap gap-1.5">
                      {service.dependencies.downstream.map((down) => (
                        <button
                          key={down}
                          onClick={() => setSelectedServiceId(down)}
                          className="rounded border border-slate-700 bg-slate-800 px-2 py-1 text-xs text-slate-300 hover:border-indigo-500 hover:text-white transition-colors"
                        >
                          {down}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Data Storage & Message Queues */}
              <div className="rounded border border-slate-800 bg-slate-950/30 p-4">
                <div className="text-xs font-semibold text-slate-300 mb-2">
                  Databases & Streaming Brokers
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-slate-500">Persistent Databases: </span>
                    <span className="text-slate-200">
                      {service.dependencies.databases.join(', ') || 'Stateless'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500">Message Topics / Queues: </span>
                    <span className="text-slate-200">
                      {service.dependencies.queues.join(', ') || 'None'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: SCORECARD */}
          {activeTab === 'scorecard' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between rounded border border-slate-800 bg-slate-950/40 p-4">
                <div>
                  <div className="text-xs text-slate-400">Readiness Score</div>
                  <div className="text-2xl font-bold font-mono text-white tabular-nums mt-0.5">
                    {service.scorecard.scorePercent}%
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    {service.scorecard.passedChecks} of {service.scorecard.totalChecks} standards compliant · Audited {service.scorecard.lastAudited}
                  </div>
                </div>
                <div className="text-right">
                  <span className={`text-sm font-semibold px-3 py-1 rounded border ${gradeColors[service.scorecard.overallGrade]}`}>
                    {service.scorecard.overallGrade} Tier
                  </span>
                  <div className="mt-2">
                    <button
                      onClick={() => setAuditDrawerServiceId(service.id)}
                      className="text-xs text-indigo-400 hover:underline"
                    >
                      Open Interactive Audit Checklist →
                    </button>
                  </div>
                </div>
              </div>

              {/* Rules list */}
              <div className="space-y-2">
                {service.scorecard.rules.map((rule) => (
                  <div
                    key={rule.id}
                    className="flex items-start justify-between rounded border border-slate-800/80 bg-slate-950/20 p-3 hover:bg-slate-800/30 transition-colors"
                  >
                    <div className="flex items-start gap-2.5">
                      {rule.passed ? (
                        <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-medium text-slate-200">{rule.name}</span>
                          <span className="text-[10px] uppercase font-mono text-slate-500">
                            {rule.category}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">{rule.description}</p>
                        {rule.remediationSnippet && !rule.passed && (
                          <div className="mt-2 rounded bg-slate-950 p-2 font-mono text-[11px] text-amber-300 border border-slate-800">
                            {rule.remediationSnippet}
                          </div>
                        )}
                      </div>
                    </div>
                    <span className={`text-[11px] font-medium shrink-0 ml-3 ${rule.passed ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {rule.passed ? 'PASS' : 'ACTION REQUIRED'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: API SPECS */}
          {activeTab === 'api' && (
            <div>
              {endpoints.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500">
                  No OpenAPI endpoints registered for this component.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  {/* Left: Endpoints List */}
                  <div className="space-y-1.5">
                    <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                      Endpoints ({endpoints.length})
                    </div>
                    {endpoints.map((ep, idx) => {
                      const isSelected = selectedEndpointIndex === idx;
                      const methodColors: Record<string, string> = {
                        GET: 'text-emerald-400 bg-emerald-950/60 border-emerald-800',
                        POST: 'text-blue-400 bg-blue-950/60 border-blue-800',
                        PUT: 'text-amber-400 bg-amber-950/60 border-amber-800',
                        DELETE: 'text-rose-400 bg-rose-950/60 border-rose-800',
                        PATCH: 'text-purple-400 bg-purple-950/60 border-purple-800'
                      };
                      return (
                        <button
                          key={idx}
                          onClick={() => {
                            setSelectedEndpointIndex(idx);
                            setApiTestResponse(null);
                          }}
                          className={`flex w-full items-center gap-2 rounded border px-2.5 py-2 text-left transition-colors ${
                            isSelected
                              ? 'border-indigo-500 bg-slate-800/80 text-white'
                              : 'border-slate-800 bg-slate-950/30 text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
                          }`}
                        >
                          <span className={`font-mono text-[10px] font-bold px-1.5 py-0.5 rounded border ${methodColors[ep.method]}`}>
                            {ep.method}
                          </span>
                          <span className="font-mono text-xs truncate">{ep.path}</span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Right: Endpoint Detail & Live Tester */}
                  <div className="md:col-span-2 space-y-4">
                    {currentEndpoint && (
                      <div className="rounded border border-slate-800 bg-slate-950/50 p-4 space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-xs font-bold text-indigo-400">
                                {currentEndpoint.method}
                              </span>
                              <span className="font-mono text-xs text-slate-200 font-semibold">
                                {currentEndpoint.path}
                              </span>
                            </div>
                            <p className="text-xs text-slate-400 mt-1">{currentEndpoint.summary}</p>
                          </div>
                          <button
                            onClick={handleTestApi}
                            disabled={isTestingApi}
                            className="flex items-center gap-1.5 rounded bg-indigo-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-indigo-500 disabled:opacity-50 transition-colors"
                          >
                            {isTestingApi ? (
                              <RotateCcw className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <Play className="h-3.5 w-3.5 fill-current" />
                            )}
                            <span>{isTestingApi ? 'Executing...' : 'Try It Out'}</span>
                          </button>
                        </div>

                        {/* Request Body Example if present */}
                        {currentEndpoint.requestBody && (
                          <div>
                            <div className="text-[11px] font-medium text-slate-400 mb-1">
                              Request Body Example ({currentEndpoint.requestBody.contentType})
                            </div>
                            <pre className="rounded bg-slate-950 border border-slate-800 p-2.5 font-mono text-[11px] text-slate-300 overflow-x-auto">
                              {JSON.stringify(currentEndpoint.requestBody.example, null, 2)}
                            </pre>
                          </div>
                        )}

                        {/* Response Example */}
                        <div>
                          <div className="text-[11px] font-medium text-slate-400 mb-1">
                            Response Contract ({currentEndpoint.responses[0]?.status} OK)
                          </div>
                          <pre className="rounded bg-slate-950 border border-slate-800 p-2.5 font-mono text-[11px] text-slate-300 overflow-x-auto">
                            {JSON.stringify(currentEndpoint.responses[0]?.example, null, 2)}
                          </pre>
                        </div>

                        {/* Live Simulation Output Box */}
                        {apiTestResponse && (
                          <div className="border-t border-slate-800 pt-3">
                            <div className="flex items-center justify-between text-[11px] text-emerald-400 font-mono mb-1.5">
                              <span>HTTP/2 {apiTestResponse.status} OK</span>
                              <span className="text-slate-400">Latency: {apiTestResponse.latencyMs}ms</span>
                            </div>
                            <pre className="rounded bg-slate-950 border border-emerald-900/50 p-2.5 font-mono text-[11px] text-emerald-300 overflow-x-auto">
                              {JSON.stringify(apiTestResponse.body, null, 2)}
                            </pre>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: TECHDOCS */}
          {activeTab === 'docs' && (
            <div className="space-y-4">
              {(!service.techDocs || service.techDocs.length === 0) ? (
                <div className="p-8 text-center text-xs text-slate-500">
                  No TechDocs published for this service yet. Add docs/index.md to repository.
                </div>
              ) : (
                <div className="space-y-6">
                  {service.techDocs.map((doc) => (
                    <div key={doc.id} className="rounded border border-slate-800 bg-slate-950/40 p-5">
                      <h3 className="text-sm font-semibold text-slate-100 mb-3 border-b border-slate-800 pb-2">
                        {doc.title}
                      </h3>
                      <div className="prose prose-invert prose-xs max-w-none text-slate-300 space-y-2 whitespace-pre-wrap font-sans text-xs leading-relaxed">
                        {doc.content}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 5: DEPLOYMENTS & GIT */}
          {activeTab === 'deployments' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                  Recent Production Deploys
                </span>
                <span className="text-xs text-slate-500 font-mono">Synced via ArgoCD GitOps</span>
              </div>
              <div className="space-y-2.5">
                {service.deployments.map((dep) => (
                  <div
                    key={dep.id}
                    className="flex items-center justify-between rounded border border-slate-800 bg-slate-950/30 p-3.5"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-8 w-8 items-center justify-center rounded bg-slate-800 text-emerald-400 font-mono text-xs">
                        <Check className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-semibold text-slate-200">
                            {dep.version}
                          </span>
                          <span className="text-[11px] text-slate-500">({dep.commitHash})</span>
                          <span className="rounded bg-emerald-950 border border-emerald-800 px-1.5 py-0.2 text-[10px] text-emerald-400 uppercase font-mono">
                            {dep.environment}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">{dep.commitMessage}</p>
                      </div>
                    </div>
                    <div className="text-right text-[11px] text-slate-500">
                      <div>{dep.deployedAt}</div>
                      <div>by {dep.deployedBy}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: KUBERNETES PODS */}
          {activeTab === 'k8s' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="rounded border border-slate-800 bg-slate-950/40 p-3">
                  <div className="text-[11px] text-slate-500">Cluster</div>
                  <div className="text-xs font-semibold font-mono text-slate-200 mt-1">
                    {service.kubernetes.cluster}
                  </div>
                </div>
                <div className="rounded border border-slate-800 bg-slate-950/40 p-3">
                  <div className="text-[11px] text-slate-500">Namespace</div>
                  <div className="text-xs font-semibold font-mono text-slate-200 mt-1">
                    {service.kubernetes.namespace}
                  </div>
                </div>
                <div className="rounded border border-slate-800 bg-slate-950/40 p-3">
                  <div className="text-[11px] text-slate-500">Ready Replicas</div>
                  <div className="text-xs font-semibold font-mono text-emerald-400 tabular-nums mt-1">
                    {service.kubernetes.replicas} / {service.kubernetes.replicas} Pods
                  </div>
                </div>
                <div className="rounded border border-slate-800 bg-slate-950/40 p-3">
                  <div className="text-[11px] text-slate-500">24h Restarts</div>
                  <div className="text-xs font-semibold font-mono text-slate-200 tabular-nums mt-1">
                    {service.kubernetes.restarts24h} restarts
                  </div>
                </div>
              </div>

              {/* Simulated Pods grid */}
              <div>
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                  Running Pod Instances ({service.kubernetes.replicas})
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                  {Array.from({ length: Math.min(service.kubernetes.replicas, 6) }).map((_, i) => (
                    <div
                      key={i}
                      className="rounded border border-slate-800 bg-slate-950/30 p-2.5 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                        <span className="font-mono text-[11px] text-slate-300">
                          {service.name}-{Math.random().toString(36).substring(2, 7)}-{i}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono">1/1 Ready</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
