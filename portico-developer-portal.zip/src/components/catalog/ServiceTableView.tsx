import React from 'react';
import { ServiceEntity } from '../../types/catalog';
import { usePortal } from '../../context/PortalContext';
import { ChevronRight, ShieldCheck } from 'lucide-react';

interface ServiceTableViewProps {
  services: ServiceEntity[];
}

export const ServiceTableView: React.FC<ServiceTableViewProps> = ({ services }) => {
  const { setSelectedServiceId, setAuditDrawerServiceId } = usePortal();

  const gradeColors: Record<string, string> = {
    Platinum: 'text-emerald-400',
    Gold: 'text-amber-400',
    Silver: 'text-slate-300',
    Bronze: 'text-amber-600',
    'Needs Review': 'text-rose-400'
  };

  return (
    <div className="overflow-x-auto rounded-lg border border-slate-800 bg-slate-900/50">
      <table className="w-full text-left text-xs">
        <thead className="border-b border-slate-800 bg-slate-950/60 text-[11px] font-medium uppercase tracking-wider text-slate-400 font-mono">
          <tr>
            <th className="py-3 px-4">Entity</th>
            <th className="py-3 px-4">Type</th>
            <th className="py-3 px-4">Owner Squad</th>
            <th className="py-3 px-4">Tier</th>
            <th className="py-3 px-4">Scorecard</th>
            <th className="py-3 px-4 text-right">Uptime</th>
            <th className="py-3 px-4 text-right">p99</th>
            <th className="py-3 px-4 text-right">Deploys</th>
            <th className="py-3 px-4 text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-800/60">
          {services.map((svc) => (
            <tr
              key={svc.id}
              onClick={() => setSelectedServiceId(svc.id)}
              className="hover:bg-slate-800/40 cursor-pointer transition-colors group"
            >
              <td className="py-3 px-4">
                <div className="font-semibold text-slate-100 group-hover:text-indigo-400 transition-colors">
                  {svc.name}
                </div>
                <div className="text-[11px] text-slate-500 font-mono">{svc.language} · {svc.framework}</div>
              </td>
              <td className="py-3 px-4 capitalize text-slate-400 font-mono text-[11px]">
                {svc.type}
              </td>
              <td className="py-3 px-4 text-slate-300">
                {svc.ownerTeam}
              </td>
              <td className="py-3 px-4 text-slate-400 text-[11px]">
                {svc.tier.split(' ')[0]} {svc.tier.split(' ')[1]}
              </td>
              <td className="py-3 px-4 font-mono font-medium">
                <span className={gradeColors[svc.scorecard.overallGrade] || 'text-slate-400'}>
                  {svc.scorecard.overallGrade} ({svc.scorecard.scorePercent}%)
                </span>
              </td>
              <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-200">
                {svc.metrics.uptime}%
              </td>
              <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-200">
                {svc.metrics.p99LatencyMs}ms
              </td>
              <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-400">
                {svc.metrics.deployFrequency}
              </td>
              <td className="py-3 px-4 text-right">
                <div className="flex items-center justify-end gap-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setAuditDrawerServiceId(svc.id);
                    }}
                    className="p-1 text-slate-500 hover:text-indigo-400 transition-colors"
                    title="Audit checks"
                  >
                    <ShieldCheck className="h-4 w-4" />
                  </button>
                  <ChevronRight className="h-4 w-4 text-slate-600 group-hover:text-slate-300" />
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
