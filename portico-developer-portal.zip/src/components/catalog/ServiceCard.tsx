import React from 'react';
import { ServiceEntity } from '../../types/catalog';
import { usePortal } from '../../context/PortalContext';
import { Server, Activity, ShieldCheck, ChevronRight } from 'lucide-react';

interface ServiceCardProps {
  service: ServiceEntity;
}

export const ServiceCard: React.FC<ServiceCardProps> = ({ service }) => {
  const { setSelectedServiceId, setAuditDrawerServiceId } = usePortal();

  const gradeColors: Record<string, string> = {
    Platinum: 'text-emerald-400',
    Gold: 'text-amber-400',
    Silver: 'text-slate-300',
    Bronze: 'text-amber-600',
    'Needs Review': 'text-rose-400'
  };

  return (
    <div
      onClick={() => setSelectedServiceId(service.id)}
      className="group relative flex flex-col justify-between rounded-lg border border-slate-800 bg-slate-900/60 p-4 transition-all duration-200 hover:border-slate-700 hover:bg-slate-800/40 cursor-pointer"
    >
      <div>
        {/* Unboxed Header Metadata */}
        <div className="flex items-center justify-between text-xs text-slate-500 mb-2 font-mono">
          <div className="flex items-center gap-1.5">
            <span className="capitalize">{service.type}</span>
            <span aria-hidden="true">·</span>
            <span className="capitalize">{service.lifecycle}</span>
          </div>
          <span className={`font-semibold ${gradeColors[service.scorecard.overallGrade] || 'text-slate-400'}`}>
            {service.scorecard.overallGrade} ({service.scorecard.scorePercent}%)
          </span>
        </div>

        {/* Title */}
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-100 group-hover:text-indigo-400 transition-colors">
            {service.name}
          </h3>
          <ChevronRight className="h-4 w-4 text-slate-600 group-hover:text-slate-300 group-hover:translate-x-0.5 transition-all" />
        </div>

        {/* Description */}
        <p className="mt-1.5 text-xs text-slate-400 line-clamp-2 leading-relaxed">
          {service.description}
        </p>

        {/* Clean unboxed stack metadata */}
        <div className="mt-3 flex items-center gap-1.5 text-[11px] text-slate-500">
          <span>{service.language}</span>
          <span aria-hidden="true">·</span>
          <span className="truncate">{service.framework}</span>
          <span aria-hidden="true">·</span>
          <span className="truncate">{service.ownerTeam}</span>
        </div>
      </div>

      {/* Bottom Telemetry Metrics Strip */}
      <div className="mt-4 border-t border-slate-800/80 pt-3 flex items-center justify-between text-[11px] font-mono">
        <div className="flex items-center gap-3 text-slate-400">
          <div>
            <span className="text-slate-500">Uptime: </span>
            <span className="text-slate-200 tabular-nums">{service.metrics.uptime}%</span>
          </div>
          <div>
            <span className="text-slate-500">p99: </span>
            <span className="text-slate-200 tabular-nums">{service.metrics.p99LatencyMs}ms</span>
          </div>
        </div>

        <button
          onClick={(e) => {
            e.stopPropagation();
            setAuditDrawerServiceId(service.id);
          }}
          className="text-slate-400 hover:text-indigo-400 text-[11px] flex items-center gap-1 transition-colors"
        >
          <ShieldCheck className="h-3 w-3" />
          <span>Audit</span>
        </button>
      </div>
    </div>
  );
};
