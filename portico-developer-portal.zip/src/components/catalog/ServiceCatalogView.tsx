import React, { useState, useMemo } from 'react';
import { usePortal } from '../../context/PortalContext';
import { ServiceCard } from './ServiceCard';
import { ServiceTableView } from './ServiceTableView';
import { ServiceDetailModal } from './ServiceDetailModal';
import {
  Search,
  Filter,
  LayoutGrid,
  List,
  Server,
  ShieldCheck,
  Zap,
  TrendingUp,
  Plus
} from 'lucide-react';

export const ServiceCatalogView: React.FC = () => {
  const { services, selectedService, setSelectedServiceId, setIsScaffolderModalOpen, setSelectedTemplate } = usePortal();

  const [search, setSearch] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedLifecycle, setSelectedLifecycle] = useState<string>('all');
  const [selectedTeam, setSelectedTeam] = useState<string>('all');
  const [selectedTier, setSelectedTier] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  // Extract unique teams
  const uniqueTeams = useMemo(() => {
    return Array.from(new Set(services.map((s) => s.ownerTeam))).sort();
  }, [services]);

  // Filtered services
  const filteredServices = useMemo(() => {
    return services.filter((s) => {
      const matchSearch =
        !search ||
        s.name.toLowerCase().includes(search.toLowerCase()) ||
        s.description.toLowerCase().includes(search.toLowerCase()) ||
        s.tags.some((t) => t.toLowerCase().includes(search.toLowerCase())) ||
        s.language.toLowerCase().includes(search.toLowerCase());

      const matchType = selectedType === 'all' || s.type === selectedType;
      const matchLifecycle = selectedLifecycle === 'all' || s.lifecycle === selectedLifecycle;
      const matchTeam = selectedTeam === 'all' || s.ownerTeam === selectedTeam;
      const matchTier = selectedTier === 'all' || s.tier.includes(selectedTier);

      return matchSearch && matchType && matchLifecycle && matchTeam && matchTier;
    });
  }, [services, search, selectedType, selectedLifecycle, selectedTeam, selectedTier]);

  // Aggregate stats
  const totalCount = services.length;
  const tier1Count = services.filter((s) => s.tier.includes('Tier 1')).length;
  const avgScore = Math.round(
    services.reduce((acc, s) => acc + s.scorecard.scorePercent, 0) / (totalCount || 1)
  );
  const productionCount = services.filter((s) => s.lifecycle === 'production').length;

  return (
    <div className="space-y-6">
      {/* Top Banner & Quick Metrics */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Software Service Catalog
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            System of record for all microservices, APIs, data pipelines, and infrastructure components.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setSelectedTemplate(null);
              setIsScaffolderModalOpen(true);
            }}
            className="flex items-center gap-1.5 rounded bg-indigo-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-indigo-500 transition-colors shadow-sm"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Register New Component</span>
          </button>
        </div>
      </div>

      {/* Aggregate KPI Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-3.5">
          <div className="text-[11px] text-slate-500 font-mono">Total Catalog Entities</div>
          <div className="text-xl font-semibold font-mono text-slate-100 tabular-nums mt-0.5">
            {totalCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            {productionCount} running in production
          </div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-3.5">
          <div className="text-[11px] text-slate-500 font-mono">Tier 1 Mission Critical</div>
          <div className="text-xl font-semibold font-mono text-indigo-400 tabular-nums mt-0.5">
            {tier1Count}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">99.99% SLO contract</div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-3.5">
          <div className="text-[11px] text-slate-500 font-mono">Average Readiness Score</div>
          <div className="text-xl font-semibold font-mono text-emerald-400 tabular-nums mt-0.5">
            {avgScore}%
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Scorecards across 5 domains</div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-3.5">
          <div className="text-[11px] text-slate-500 font-mono">Active Engineering Squads</div>
          <div className="text-xl font-semibold font-mono text-slate-100 tabular-nums mt-0.5">
            {uniqueTeams.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">100% CODEOWNERS linked</div>
        </div>
      </div>

      {/* Filter and Control Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 rounded-lg border border-slate-800 bg-slate-900/40 p-3">
        {/* Search */}
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, tag, stack, or owner..."
            className="w-full rounded border border-slate-800 bg-slate-950/60 pl-8 pr-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:outline-none"
          />
        </div>

        {/* Filter Dropdowns */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Type Filter */}
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="rounded border border-slate-800 bg-slate-950 px-2.5 py-1.5 text-xs text-slate-300 focus:border-indigo-500 focus:outline-none"
          >
            <option value="all">All Types</option>
            <option value="service">Services</option>
            <option value="api">APIs</option>
            <option value="pipeline">Pipelines</option>
            <option value="infra">Infrastructure</option>
          </select>

          {/* Lifecycle Filter */}
          <select
            value={selectedLifecycle}
            onChange={(e) => setSelectedLifecycle(e.target.value)}
            className="rounded border border-slate-800 bg-slate-950 px-2.5 py-1.5 text-xs text-slate-300 focus:border-indigo-500 focus:outline-none"
          >
            <option value="all">All Lifecycles</option>
            <option value="production">Production</option>
            <option value="staging">Staging</option>
            <option value="experimental">Experimental</option>
          </select>

          {/* Team Filter */}
          <select
            value={selectedTeam}
            onChange={(e) => setSelectedTeam(e.target.value)}
            className="rounded border border-slate-800 bg-slate-950 px-2.5 py-1.5 text-xs text-slate-300 focus:border-indigo-500 focus:outline-none"
          >
            <option value="all">All Squads</option>
            {uniqueTeams.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>

          {/* Tier Filter */}
          <select
            value={selectedTier}
            onChange={(e) => setSelectedTier(e.target.value)}
            className="rounded border border-slate-800 bg-slate-950 px-2.5 py-1.5 text-xs text-slate-300 focus:border-indigo-500 focus:outline-none"
          >
            <option value="all">All Tiers</option>
            <option value="Tier 1">Tier 1 (Critical)</option>
            <option value="Tier 2">Tier 2 (Essential)</option>
            <option value="Tier 3">Tier 3 (Supporting)</option>
          </select>

          {/* View Mode Toggle */}
          <div className="flex items-center rounded border border-slate-800 bg-slate-950 p-0.5">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1 rounded text-xs transition-colors ${
                viewMode === 'grid'
                  ? 'bg-slate-800 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Grid Cards"
            >
              <LayoutGrid className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-1 rounded text-xs transition-colors ${
                viewMode === 'table'
                  ? 'bg-slate-800 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Table View"
            >
              <List className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Services Grid or Table */}
      {filteredServices.length === 0 ? (
        <div className="rounded-lg border border-slate-800 bg-slate-900/30 p-12 text-center">
          <Server className="mx-auto h-8 w-8 text-slate-600 mb-3" />
          <h3 className="text-sm font-semibold text-slate-200">No components match filters</h3>
          <p className="mt-1 text-xs text-slate-500">
            Try adjusting your search query, squad selection, or lifecycle state.
          </p>
          <button
            onClick={() => {
              setSearch('');
              setSelectedType('all');
              setSelectedLifecycle('all');
              setSelectedTeam('all');
              setSelectedTier('all');
            }}
            className="mt-4 text-xs text-indigo-400 hover:underline"
          >
            Reset all filters
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredServices.map((svc) => (
            <ServiceCard key={svc.id} service={svc} />
          ))}
        </div>
      ) : (
        <ServiceTableView services={filteredServices} />
      )}

      {/* Active Service Deep-Dive Modal */}
      {selectedService && (
        <ServiceDetailModal
          service={selectedService}
          onClose={() => setSelectedServiceId(null)}
        />
      )}
    </div>
  );
};
