import React, { useState, useMemo } from 'react';
import { usePortal } from '../../context/PortalContext';
import { ScorecardAuditDrawer } from './ScorecardAuditDrawer';
import {
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Lock,
  Activity,
  Radio,
  FileCode,
  CheckCheck,
  TrendingUp,
  Search,
  ChevronRight,
  Filter
} from 'lucide-react';

export const ScorecardsView: React.FC = () => {
  const { services, setAuditDrawerServiceId, setSelectedServiceId } = usePortal();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [tierFilter, setTierFilter] = useState<string>('all');

  // Compute stats across all services
  const totalServices = services.length;
  const gradeCounts = useMemo(() => {
    const counts = { Platinum: 0, Gold: 0, Silver: 0, Bronze: 0, 'Needs Review': 0 };
    services.forEach((s) => {
      const g = s.scorecard.overallGrade;
      counts[g] = (counts[g] || 0) + 1;
    });
    return counts;
  }, [services]);

  // Overall compliance percent
  const overallAvg = useMemo(() => {
    if (totalServices === 0) return 0;
    const sum = services.reduce((acc, s) => acc + s.scorecard.scorePercent, 0);
    return Math.round(sum / totalServices);
  }, [services, totalServices]);

  // Category compliance percentages
  const categoryCompliance = useMemo(() => {
    const cats: Record<string, { total: number; passed: number }> = {
      security: { total: 0, passed: 0 },
      reliability: { total: 0, passed: 0 },
      observability: { total: 0, passed: 0 },
      docs: { total: 0, passed: 0 },
      quality: { total: 0, passed: 0 }
    };

    services.forEach((s) => {
      s.scorecard.rules.forEach((r) => {
        if (cats[r.category]) {
          cats[r.category].total += 1;
          if (r.passed) cats[r.category].passed += 1;
        }
      });
    });

    return {
      security: Math.round(((cats.security.passed || 1) / (cats.security.total || 1)) * 100),
      reliability: Math.round(((cats.reliability.passed || 1) / (cats.reliability.total || 1)) * 100),
      observability: Math.round(((cats.observability.passed || 1) / (cats.observability.total || 1)) * 100),
      docs: Math.round(((cats.docs.passed || 1) / (cats.docs.total || 1)) * 100),
      quality: Math.round(((cats.quality.passed || 1) / (cats.quality.total || 1)) * 100)
    };
  }, [services]);

  // Team Leaderboard
  const teamScores = useMemo(() => {
    const map: Record<string, { total: number; count: number }> = {};
    services.forEach((s) => {
      if (!map[s.ownerTeam]) map[s.ownerTeam] = { total: 0, count: 0 };
      map[s.ownerTeam].total += s.scorecard.scorePercent;
      map[s.ownerTeam].count += 1;
    });

    return Object.entries(map)
      .map(([team, val]) => ({
        team,
        avg: Math.round(val.total / val.count),
        servicesCount: val.count
      }))
      .sort((a, b) => b.avg - a.avg);
  }, [services]);

  // Filtered Services List
  const filteredServices = useMemo(() => {
    return services.filter((s) => {
      const matchSearch =
        !search ||
        s.name.toLowerCase().includes(search.toLowerCase()) ||
        s.ownerTeam.toLowerCase().includes(search.toLowerCase());
      const matchTier = tierFilter === 'all' || s.scorecard.overallGrade === tierFilter;
      return matchSearch && matchTier;
    });
  }, [services, search, tierFilter]);

  const gradeColors: Record<string, string> = {
    Platinum: 'text-emerald-400 bg-emerald-950/60 border-emerald-800',
    Gold: 'text-amber-400 bg-amber-950/60 border-amber-800',
    Silver: 'text-slate-300 bg-slate-800/60 border-slate-700',
    Bronze: 'text-amber-600 bg-amber-950/30 border-amber-900',
    'Needs Review': 'text-rose-400 bg-rose-950/60 border-rose-800'
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Engineering Production Scorecards
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Automated production readiness, security posture, SLO definition, and documentation standards compliance.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-mono">
            System Average: <span className="text-emerald-400 font-bold tabular-nums">{overallAvg}%</span>
          </span>
        </div>
      </div>

      {/* Domain Readiness Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-3.5">
          <div className="flex items-center gap-2 text-[11px] text-slate-400 font-medium">
            <Lock className="h-3.5 w-3.5 text-indigo-400" />
            <span>Security & CVE</span>
          </div>
          <div className="text-xl font-bold font-mono text-slate-100 tabular-nums mt-1">
            {categoryCompliance.security}%
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Trivy, Vault & SBOM</div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-3.5">
          <div className="flex items-center gap-2 text-[11px] text-slate-400 font-medium">
            <Activity className="h-3.5 w-3.5 text-emerald-400" />
            <span>SRE & Probes</span>
          </div>
          <div className="text-xl font-bold font-mono text-slate-100 tabular-nums mt-1">
            {categoryCompliance.reliability}%
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">SLO & /healthz</div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-3.5">
          <div className="flex items-center gap-2 text-[11px] text-slate-400 font-medium">
            <Radio className="h-3.5 w-3.5 text-sky-400" />
            <span>Telemetry</span>
          </div>
          <div className="text-xl font-bold font-mono text-slate-100 tabular-nums mt-1">
            {categoryCompliance.observability}%
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">OpenTelemetry W3C</div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-3.5">
          <div className="flex items-center gap-2 text-[11px] text-slate-400 font-medium">
            <FileCode className="h-3.5 w-3.5 text-amber-400" />
            <span>Catalog & Docs</span>
          </div>
          <div className="text-xl font-bold font-mono text-slate-100 tabular-nums mt-1">
            {categoryCompliance.docs}%
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">OpenAPI 3.0 & Runbooks</div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-3.5">
          <div className="flex items-center gap-2 text-[11px] text-slate-400 font-medium">
            <CheckCheck className="h-3.5 w-3.5 text-purple-400" />
            <span>Code Quality</span>
          </div>
          <div className="text-xl font-bold font-mono text-slate-100 tabular-nums mt-1">
            {categoryCompliance.quality}%
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Coverage & Distroless</div>
        </div>
      </div>

      {/* Tier Distribution & Squad Leaderboard */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Tier Distribution */}
        <div className="rounded-lg border border-slate-800 bg-slate-900/40 p-4">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
            Readiness Tier Distribution
          </h3>
          <div className="space-y-2.5">
            {[
              { grade: 'Platinum', label: 'Platinum (100% Standards Met)', count: gradeCounts.Platinum, color: 'bg-emerald-500' },
              { grade: 'Gold', label: 'Gold (>= 85% Compliant)', count: gradeCounts.Gold, color: 'bg-amber-400' },
              { grade: 'Silver', label: 'Silver (>= 70% Compliant)', count: gradeCounts.Silver, color: 'bg-slate-400' },
              { grade: 'Bronze', label: 'Bronze (< 70% Compliant)', count: gradeCounts.Bronze, color: 'bg-amber-600' }
            ].map((tier) => {
              const pct = Math.round((tier.count / totalServices) * 100);
              return (
                <div key={tier.grade} className="text-xs">
                  <div className="flex items-center justify-between text-slate-300 mb-1">
                    <span className="font-medium">{tier.label}</span>
                    <span className="font-mono text-slate-400">{tier.count} ({pct}%)</span>
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full ${tier.color} rounded-full transition-all duration-500`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Squad Leaderboard */}
        <div className="md:col-span-2 rounded-lg border border-slate-800 bg-slate-900/40 p-4">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
            Squad Scorecard Leaderboard
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {teamScores.map((t, idx) => (
              <div
                key={t.team}
                className="flex items-center justify-between rounded border border-slate-800 bg-slate-950/40 p-2.5"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <span className="text-[11px] font-mono text-slate-500 w-4">
                    #{idx + 1}
                  </span>
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-slate-200 truncate">{t.team}</div>
                    <div className="text-[10px] text-slate-500 font-mono">
                      {t.servicesCount} services managed
                    </div>
                  </div>
                </div>
                <span className="text-sm font-bold font-mono text-emerald-400 tabular-nums">
                  {t.avg}%
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Service-by-Service Scorecards Table */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Component Readiness Audits ({filteredServices.length})
          </h3>

          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-500" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Filter services..."
                className="rounded border border-slate-800 bg-slate-900 pl-8 pr-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none"
              />
            </div>

            <select
              value={tierFilter}
              onChange={(e) => setTierFilter(e.target.value)}
              className="rounded border border-slate-800 bg-slate-900 px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none"
            >
              <option value="all">All Tiers</option>
              <option value="Platinum">Platinum</option>
              <option value="Gold">Gold</option>
              <option value="Silver">Silver</option>
              <option value="Bronze">Bronze</option>
            </select>
          </div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-slate-900/50 overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-800 bg-slate-950/60 text-[11px] font-medium uppercase tracking-wider text-slate-400 font-mono">
              <tr>
                <th className="py-3 px-4">Component</th>
                <th className="py-3 px-4">Squad</th>
                <th className="py-3 px-4">Tier</th>
                <th className="py-3 px-4">Readiness Grade</th>
                <th className="py-3 px-4 text-center">Security</th>
                <th className="py-3 px-4 text-center">SRE / Probes</th>
                <th className="py-3 px-4 text-center">Observability</th>
                <th className="py-3 px-4 text-center">Docs</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredServices.map((svc) => {
                const secPassed = svc.scorecard.rules.filter((r) => r.category === 'security' && r.passed).length;
                const secTotal = svc.scorecard.rules.filter((r) => r.category === 'security').length || 1;
                const relPassed = svc.scorecard.rules.filter((r) => r.category === 'reliability' && r.passed).length;
                const relTotal = svc.scorecard.rules.filter((r) => r.category === 'reliability').length || 1;
                const obsPassed = svc.scorecard.rules.filter((r) => r.category === 'observability' && r.passed).length;
                const obsTotal = svc.scorecard.rules.filter((r) => r.category === 'observability').length || 1;
                const docPassed = svc.scorecard.rules.filter((r) => r.category === 'docs' && r.passed).length;
                const docTotal = svc.scorecard.rules.filter((r) => r.category === 'docs').length || 1;

                return (
                  <tr
                    key={svc.id}
                    className="hover:bg-slate-800/30 transition-colors"
                  >
                    <td className="py-3 px-4">
                      <button
                        onClick={() => setSelectedServiceId(svc.id)}
                        className="font-semibold text-slate-100 hover:text-indigo-400 transition-colors text-left"
                      >
                        {svc.name}
                      </button>
                      <div className="text-[11px] text-slate-500 font-mono">{svc.language}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-300">{svc.ownerTeam}</td>
                    <td className="py-3 px-4 text-slate-400 font-mono text-[11px]">
                      {svc.tier.split(' ')[0]} {svc.tier.split(' ')[1]}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`text-[11px] font-semibold px-2 py-0.5 rounded border ${gradeColors[svc.scorecard.overallGrade]}`}>
                        {svc.scorecard.overallGrade} ({svc.scorecard.scorePercent}%)
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center font-mono text-[11px]">
                      <span className={secPassed === secTotal ? 'text-emerald-400' : 'text-amber-400'}>
                        {secPassed}/{secTotal}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center font-mono text-[11px]">
                      <span className={relPassed === relTotal ? 'text-emerald-400' : 'text-amber-400'}>
                        {relPassed}/{relTotal}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center font-mono text-[11px]">
                      <span className={obsPassed === obsTotal ? 'text-emerald-400' : 'text-amber-400'}>
                        {obsPassed}/{obsTotal}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center font-mono text-[11px]">
                      <span className={docPassed === docTotal ? 'text-emerald-400' : 'text-amber-400'}>
                        {docPassed}/{docTotal}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => setAuditDrawerServiceId(svc.id)}
                        className="rounded border border-slate-700 bg-slate-800 px-2.5 py-1 text-xs text-slate-200 hover:bg-slate-700 transition-colors"
                      >
                        Audit Checks
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Side Audit Drawer */}
      <ScorecardAuditDrawer />
    </div>
  );
};
