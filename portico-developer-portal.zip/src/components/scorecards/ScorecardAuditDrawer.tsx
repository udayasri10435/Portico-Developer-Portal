import React, { useState } from 'react';
import { usePortal } from '../../context/PortalContext';
import {
  X,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Copy,
  Check,
  ExternalLink,
  Zap,
  Info
} from 'lucide-react';

export const ScorecardAuditDrawer: React.FC = () => {
  const { auditDrawerService, setAuditDrawerServiceId, toggleScorecardCheck, reAuditAllChecks } = usePortal();
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isAuditing, setIsAuditing] = useState(false);

  if (!auditDrawerService) return null;

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleReAudit = () => {
    setIsAuditing(true);
    setTimeout(() => {
      reAuditAllChecks(auditDrawerService.id);
      setIsAuditing(false);
    }, 600);
  };

  const categories = [
    { id: 'security', label: 'Security & Vulnerability' },
    { id: 'reliability', label: 'Production Reliability & Probes' },
    { id: 'observability', label: 'Telemetry & Distributed Tracing' },
    { id: 'docs', label: 'Documentation & Catalog Quality' },
    { id: 'quality', label: 'Code Quality & CI/CD Gates' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
      <div
        className="w-full max-w-xl h-full bg-slate-900 border-l border-slate-800 shadow-2xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 p-5 bg-slate-950/60">
          <div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Production Readiness Audit
              </span>
            </div>
            <h2 className="text-base font-semibold text-white mt-1">
              {auditDrawerService.name}
            </h2>
            <div className="text-xs text-slate-500 mt-0.5">
              {auditDrawerService.ownerTeam} · {auditDrawerService.tier}
            </div>
          </div>

          <button
            onClick={() => setAuditDrawerServiceId(null)}
            className="rounded p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Current Score Summary */}
        <div className="border-b border-slate-800 bg-slate-950/40 p-5 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">Compliance Grade</div>
            <div className="text-2xl font-bold font-mono text-white tabular-nums mt-0.5">
              {auditDrawerService.scorecard.scorePercent}%
            </div>
            <div className="text-xs text-slate-500 mt-0.5">
              {auditDrawerService.scorecard.passedChecks} of {auditDrawerService.scorecard.totalChecks} standards met
            </div>
          </div>

          <div className="flex flex-col items-end gap-2">
            <span className="rounded border border-emerald-800 bg-emerald-950/60 px-3 py-1 text-xs font-semibold text-emerald-400 font-mono">
              {auditDrawerService.scorecard.overallGrade} Tier
            </span>
            <button
              onClick={handleReAudit}
              disabled={isAuditing}
              className="flex items-center gap-1.5 text-xs text-indigo-400 hover:text-indigo-300 transition-colors disabled:opacity-50"
            >
              <RotateCcw className={`h-3 w-3 ${isAuditing ? 'animate-spin' : ''}`} />
              <span>{isAuditing ? 'Auditing telemetry...' : 'Re-evaluate All Rules'}</span>
            </button>
          </div>
        </div>

        {/* Rules Checklist Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-6">
          {categories.map((cat) => {
            const rules = auditDrawerService.scorecard.rules.filter(
              (r) => r.category === cat.id
            );
            if (rules.length === 0) return null;

            return (
              <div key={cat.id} className="space-y-3">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-300 border-b border-slate-800 pb-1.5">
                  <span>{cat.label}</span>
                  <span className="text-slate-500 font-mono text-[11px]">
                    {rules.filter((r) => r.passed).length}/{rules.length}
                  </span>
                </div>

                <div className="space-y-2">
                  {rules.map((rule) => (
                    <div
                      key={rule.id}
                      className="rounded border border-slate-800 bg-slate-950/40 p-3 hover:border-slate-700 transition-colors"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-2.5">
                          <button
                            type="button"
                            onClick={() => toggleScorecardCheck(auditDrawerService.id, rule.id)}
                            className="mt-0.5 text-slate-400 hover:text-white transition-colors"
                            title="Click to toggle check state"
                          >
                            {rule.passed ? (
                              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                            ) : (
                              <AlertTriangle className="h-4 w-4 text-amber-400" />
                            )}
                          </button>
                          <div>
                            <div className="text-xs font-semibold text-slate-200">
                              {rule.name}
                            </div>
                            <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                              {rule.description}
                            </p>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => toggleScorecardCheck(auditDrawerService.id, rule.id)}
                          className={`text-[10px] font-mono px-2 py-0.5 rounded border whitespace-nowrap transition-colors ${
                            rule.passed
                              ? 'border-emerald-800 bg-emerald-950/50 text-emerald-400 hover:bg-emerald-900/50'
                              : 'border-amber-800 bg-amber-950/50 text-amber-400 hover:bg-amber-900/50'
                          }`}
                        >
                          {rule.passed ? 'PASS' : 'FAIL'}
                        </button>
                      </div>

                      {/* Remediation Fix Guide */}
                      {rule.remediationSnippet && (
                        <div className="mt-3 pt-2.5 border-t border-slate-800/80">
                          <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono mb-1">
                            <span>REMEDIATION GUIDE:</span>
                            <button
                              onClick={() => handleCopy(rule.id, rule.remediationSnippet)}
                              className="flex items-center gap-1 text-slate-400 hover:text-white transition-colors"
                            >
                              {copiedId === rule.id ? (
                                <Check className="h-3 w-3 text-emerald-400" />
                              ) : (
                                <Copy className="h-3 w-3" />
                              )}
                              <span>{copiedId === rule.id ? 'Copied' : 'Copy Snippet'}</span>
                            </button>
                          </div>
                          <pre className="rounded bg-slate-950 border border-slate-800 p-2 font-mono text-[10px] text-amber-300/90 overflow-x-auto whitespace-pre-wrap">
                            {rule.remediationSnippet}
                          </pre>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-800 bg-slate-950/60 p-4 flex items-center justify-between text-xs text-slate-500">
          <span>Toggling checks updates organization DORA scores live</span>
          <button
            onClick={() => setAuditDrawerServiceId(null)}
            className="rounded bg-slate-800 px-3 py-1.5 text-xs text-slate-200 hover:bg-slate-700 transition-colors"
          >
            Done Auditing
          </button>
        </div>
      </div>
    </div>
  );
};
