import React, { useState, useMemo } from 'react';
import { usePortal } from '../../context/PortalContext';
import { ServiceEntity } from '../../types/catalog';
import {
  Layers,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  ShieldCheck,
  ExternalLink,
  ChevronRight,
  Filter
} from 'lucide-react';

interface NodePosition {
  id: string;
  name: string;
  type: string;
  tier: string;
  team: string;
  x: number;
  y: number;
  grade: string;
}

export const SystemGraphView: React.FC = () => {
  const { services, setSelectedServiceId } = usePortal();
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>('auth-gateway');
  const [filterTeam, setFilterTeam] = useState<string>('all');
  const [zoomLevel, setZoomLevel] = useState<number>(1);

  // Position nodes in a clean, layered architecture topology
  const nodes: NodePosition[] = useMemo(() => {
    // Layer 1: Edge & Ingress (y: 60)
    // Layer 2: API & Gateway & Web Frontends (y: 180)
    // Layer 3: Core Domain Services (y: 300)
    // Layer 4: Infrastructure & Storage & Async (y: 420)
    const positions: Record<string, { x: number; y: number }> = {
      'edge-proxy-ingress': { x: 450, y: 50 },
      'customer-web-portal': { x: 220, y: 160 },
      'auth-gateway': { x: 450, y: 160 },
      'checkout-orchestrator': { x: 680, y: 160 },
      'fraud-risk-evaluator': { x: 200, y: 290 },
      'billing-engine': { x: 450, y: 290 },
      'inventory-service': { x: 700, y: 290 },
      'notification-dispatcher': { x: 220, y: 410 },
      'search-indexer-pipeline': { x: 680, y: 410 }
    };

    return services.map((s, idx) => {
      const pos = positions[s.id] || {
        x: 150 + ((idx * 160) % 700),
        y: 480 + Math.floor(idx / 4) * 80
      };

      return {
        id: s.id,
        name: s.name,
        type: s.type,
        tier: s.tier,
        team: s.ownerTeam,
        x: pos.x,
        y: pos.y,
        grade: s.scorecard.overallGrade
      };
    });
  }, [services]);

  // Directed edges based on dependencies
  const links = useMemo(() => {
    const edgeList: { from: NodePosition; to: NodePosition; isHighlight: boolean }[] = [];

    services.forEach((s) => {
      const fromNode = nodes.find((n) => n.id === s.id);
      if (!fromNode) return;

      s.dependencies.downstream.forEach((targetId) => {
        const toNode = nodes.find((n) => n.id === targetId);
        if (toNode) {
          const isHighlight = selectedNodeId === s.id || selectedNodeId === targetId;
          edgeList.push({ from: fromNode, to: toNode, isHighlight });
        }
      });
    });

    return edgeList;
  }, [services, nodes, selectedNodeId]);

  const selectedService = services.find((s) => s.id === selectedNodeId) || services[0];

  const uniqueTeams = useMemo(() => {
    return Array.from(new Set(services.map((s) => s.ownerTeam))).sort();
  }, [services]);

  const gradeColors: Record<string, string> = {
    Platinum: '#10b981',
    Gold: '#f59e0b',
    Silver: '#94a3b8',
    Bronze: '#d97706',
    'Needs Review': '#f43f5e'
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Architecture Topology & Dependency Graph
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Real-time interactive dependency visualization across distributed microservices, message buses, and data tiers.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Team Filter */}
          <select
            value={filterTeam}
            onChange={(e) => setFilterTeam(e.target.value)}
            className="rounded border border-slate-800 bg-slate-900 px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none"
          >
            <option value="all">All Squads</option>
            {uniqueTeams.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>

          {/* Zoom controls */}
          <div className="flex items-center rounded border border-slate-800 bg-slate-900 p-0.5">
            <button
              onClick={() => setZoomLevel((z) => Math.min(z + 0.15, 1.5))}
              className="p-1 text-slate-400 hover:text-white transition-colors"
              title="Zoom In"
            >
              <ZoomIn className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => setZoomLevel((z) => Math.max(z - 0.15, 0.7))}
              className="p-1 text-slate-400 hover:text-white transition-colors"
              title="Zoom Out"
            >
              <ZoomOut className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => setZoomLevel(1)}
              className="p-1 text-slate-400 hover:text-white transition-colors"
              title="Reset Zoom"
            >
              <RotateCcw className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Graph Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        {/* SVG Interactive Canvas */}
        <div className="lg:col-span-3 rounded-lg border border-slate-800 bg-slate-950 p-2 overflow-hidden relative shadow-inner">
          <div className="absolute top-4 left-4 z-10 text-[11px] font-mono text-slate-500 bg-slate-900/80 px-2.5 py-1 rounded border border-slate-800 backdrop-blur-xs">
            Interactive Topology · Click node to inspect details
          </div>

          <div className="overflow-auto max-h-[640px] flex items-center justify-center p-4">
            <svg
              width="900"
              height="540"
              viewBox="0 0 900 540"
              style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'top center', transition: 'transform 0.2s' }}
              className="select-none"
            >
              <defs>
                <marker
                  id="arrow"
                  viewBox="0 0 10 10"
                  refX="18"
                  refY="5"
                  markerWidth="6"
                  markerHeight="6"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 1 L 10 5 L 0 9 z" fill="#475569" />
                </marker>
                <marker
                  id="arrow-active"
                  viewBox="0 0 10 10"
                  refX="18"
                  refY="5"
                  markerWidth="6"
                  markerHeight="6"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 1 L 10 5 L 0 9 z" fill="#818cf8" />
                </marker>
              </defs>

              {/* Render Connection Lines */}
              {links.map((link, idx) => {
                const isMatch = filterTeam === 'all' || link.from.team === filterTeam || link.to.team === filterTeam;
                return (
                  <path
                    key={idx}
                    d={`M ${link.from.x} ${link.from.y} C ${link.from.x} ${(link.from.y + link.to.y) / 2}, ${link.to.x} ${(link.from.y + link.to.y) / 2}, ${link.to.x} ${link.to.y}`}
                    fill="none"
                    stroke={link.isHighlight ? '#6366f1' : '#334155'}
                    strokeWidth={link.isHighlight ? 2.5 : 1.2}
                    strokeDasharray={link.isHighlight ? '4 2' : 'none'}
                    markerEnd={link.isHighlight ? 'url(#arrow-active)' : 'url(#arrow)'}
                    opacity={isMatch ? (link.isHighlight ? 1 : 0.6) : 0.15}
                    className="transition-all duration-300"
                  />
                );
              })}

              {/* Render Node Boxes */}
              {nodes.map((node) => {
                const isSelected = selectedNodeId === node.id;
                const isTeamMatch = filterTeam === 'all' || node.team === filterTeam;

                return (
                  <g
                    key={node.id}
                    transform={`translate(${node.x}, ${node.y})`}
                    onClick={() => setSelectedNodeId(node.id)}
                    className="cursor-pointer"
                    opacity={isTeamMatch ? 1 : 0.25}
                  >
                    {/* Node Container Card */}
                    <rect
                      x="-80"
                      y="-26"
                      width="160"
                      height="52"
                      rx="6"
                      fill={isSelected ? '#1e293b' : '#0f172a'}
                      stroke={isSelected ? '#6366f1' : '#334155'}
                      strokeWidth={isSelected ? 2 : 1}
                      className="transition-colors hover:stroke-slate-400"
                    />

                    {/* Readiness grade circle */}
                    <circle
                      cx="-64"
                      cy="0"
                      r="4.5"
                      fill={gradeColors[node.grade] || '#94a3b8'}
                    />

                    {/* Node Title */}
                    <text
                      x="-50"
                      y="-4"
                      fill={isSelected ? '#ffffff' : '#f1f5f9'}
                      fontSize="11"
                      fontWeight="600"
                      fontFamily="var(--font-sans)"
                    >
                      {node.name.length > 18 ? node.name.slice(0, 16) + '..' : node.name}
                    </text>

                    {/* Node Metadata Subtitle */}
                    <text
                      x="-50"
                      y="12"
                      fill="#64748b"
                      fontSize="9.5"
                      fontFamily="var(--font-mono)"
                    >
                      {node.team.length > 18 ? node.team.slice(0, 16) + '..' : node.team}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Selected Service Quick-Inspector Drawer */}
        <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-5 space-y-4">
          {selectedService ? (
            <div>
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono uppercase text-slate-500">
                  Inspected Node
                </span>
                <span className="text-[11px] font-mono text-emerald-400 font-semibold">
                  {selectedService.scorecard.overallGrade}
                </span>
              </div>

              <h3 className="text-base font-bold text-white mt-1">
                {selectedService.name}
              </h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                {selectedService.description}
              </p>

              <div className="space-y-2 pt-3 border-t border-slate-800 text-xs mt-3">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Owning Squad:</span>
                  <span className="text-slate-200 font-medium">{selectedService.ownerTeam}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Stack:</span>
                  <span className="text-slate-200 font-mono text-[11px]">{selectedService.language}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Uptime:</span>
                  <span className="text-emerald-400 font-mono font-semibold tabular-nums">
                    {selectedService.metrics.uptime}%
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">p99 Latency:</span>
                  <span className="text-slate-200 font-mono tabular-nums">
                    {selectedService.metrics.p99LatencyMs}ms
                  </span>
                </div>
              </div>

              {/* Dependencies Summary */}
              <div className="pt-3 border-t border-slate-800 space-y-2">
                <div className="text-[11px] font-semibold text-slate-300">
                  Direct Downstream Dependencies:
                </div>
                {selectedService.dependencies.downstream.length === 0 ? (
                  <div className="text-xs text-slate-500 italic">No microservice dependencies</div>
                ) : (
                  <div className="flex flex-wrap gap-1">
                    {selectedService.dependencies.downstream.map((d) => (
                      <button
                        key={d}
                        onClick={() => setSelectedNodeId(d)}
                        className="rounded border border-slate-700 bg-slate-800 px-2 py-0.5 text-[11px] text-slate-300 hover:text-white"
                      >
                        {d}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-slate-800">
                <button
                  onClick={() => setSelectedServiceId(selectedService.id)}
                  className="w-full flex items-center justify-center gap-1.5 rounded bg-indigo-600 px-3 py-2 text-xs font-medium text-white hover:bg-indigo-500 transition-colors"
                >
                  <span>Open Full Component Details</span>
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ) : (
            <div className="text-xs text-slate-500 text-center py-6">
              Click a node on the canvas to inspect its architecture.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
