import React, { useState, useMemo } from 'react';
import { usePortal } from '../../context/PortalContext';
import { Search, Server, Cpu, FileText, ShieldCheck, ArrowRight, X } from 'lucide-react';

export const CommandPalette: React.FC = () => {
  const {
    isCommandPaletteOpen,
    setIsCommandPaletteOpen,
    services,
    templates,
    setSelectedServiceId,
    setActiveTab,
    setSelectedTemplate,
    setIsScaffolderModalOpen
  } = usePortal();

  const [query, setQuery] = useState('');

  const filteredServices = useMemo(() => {
    if (!query) return services.slice(0, 4);
    const q = query.toLowerCase();
    return services.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        s.description.toLowerCase().includes(q) ||
        s.ownerTeam.toLowerCase().includes(q) ||
        s.tags.some((t) => t.toLowerCase().includes(q))
    );
  }, [services, query]);

  const filteredTemplates = useMemo(() => {
    if (!query) return templates.slice(0, 3);
    const q = query.toLowerCase();
    return templates.filter(
      (t) =>
        t.name.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.language.toLowerCase().includes(q)
    );
  }, [templates, query]);

  if (!isCommandPaletteOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 bg-black/60 backdrop-blur-sm p-4">
      <div
        className="w-full max-w-xl rounded-lg border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center border-b border-slate-800 px-3.5 py-3">
          <Search className="h-4 w-4 text-slate-400 mr-2.5 shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type a service name, golden path, team, or command..."
            className="w-full bg-transparent text-sm text-slate-100 placeholder-slate-500 focus:outline-none"
          />
          <button
            onClick={() => setIsCommandPaletteOpen(false)}
            className="text-slate-400 hover:text-slate-200"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Results Container */}
        <div className="max-h-96 overflow-y-auto p-2 space-y-3">
          {/* Services Section */}
          <div>
            <div className="px-2 py-1 text-[11px] font-medium uppercase tracking-wider text-slate-500">
              Services & Components ({filteredServices.length})
            </div>
            {filteredServices.length === 0 ? (
              <div className="px-3 py-2 text-xs text-slate-500">No services found</div>
            ) : (
              filteredServices.map((svc) => (
                <button
                  key={svc.id}
                  onClick={() => {
                    setSelectedServiceId(svc.id);
                    setActiveTab('catalog');
                    setIsCommandPaletteOpen(false);
                  }}
                  className="flex w-full items-center justify-between rounded px-2.5 py-2 text-left hover:bg-slate-800/70 transition-colors group"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Server className="h-4 w-4 text-slate-400 group-hover:text-indigo-400 shrink-0" />
                    <div className="min-w-0">
                      <div className="text-xs font-medium text-slate-200 truncate">
                        {svc.name}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">
                        {svc.ownerTeam} · {svc.language} · {svc.scorecard.overallGrade}
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="h-3.5 w-3.5 text-slate-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
              ))
            )}
          </div>

          {/* Golden Paths Section */}
          <div>
            <div className="px-2 py-1 text-[11px] font-medium uppercase tracking-wider text-slate-500">
              Golden Paths / Scaffolder ({filteredTemplates.length})
            </div>
            {filteredTemplates.map((tmpl) => (
              <button
                key={tmpl.id}
                onClick={() => {
                  setSelectedTemplate(tmpl);
                  setIsScaffolderModalOpen(true);
                  setIsCommandPaletteOpen(false);
                }}
                className="flex w-full items-center justify-between rounded px-2.5 py-2 text-left hover:bg-slate-800/70 transition-colors group"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <Cpu className="h-4 w-4 text-slate-400 group-hover:text-indigo-400 shrink-0" />
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-slate-200 truncate">
                      {tmpl.name}
                    </div>
                    <div className="text-[11px] text-slate-500 truncate">
                      {tmpl.category} · {tmpl.framework}
                    </div>
                  </div>
                </div>
                <span className="text-[10px] text-indigo-400 font-medium">Scaffold</span>
              </button>
            ))}
          </div>

          {/* Quick Nav shortcuts */}
          <div className="border-t border-slate-800/70 pt-2">
            <div className="px-2 py-1 text-[11px] font-medium uppercase tracking-wider text-slate-500">
              Quick Portals
            </div>
            <div className="grid grid-cols-2 gap-1">
              <button
                onClick={() => {
                  setActiveTab('scorecards');
                  setIsCommandPaletteOpen(false);
                }}
                className="flex items-center gap-2 rounded px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800 transition-colors"
              >
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                <span>Production Scorecards</span>
              </button>
              <button
                onClick={() => {
                  setActiveTab('techdocs');
                  setIsCommandPaletteOpen(false);
                }}
                className="flex items-center gap-2 rounded px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800 transition-colors"
              >
                <FileText className="h-3.5 w-3.5 text-sky-400" />
                <span>TechDocs & Runbooks</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="border-t border-slate-800 bg-slate-950/60 px-3.5 py-2 text-[11px] text-slate-500 flex items-center justify-between">
          <span>Navigate with mouse or click item to open</span>
          <kbd className="rounded bg-slate-800 px-1 py-0.5 font-mono text-[10px] text-slate-400">
            Esc to close
          </kbd>
        </div>
      </div>
    </div>
  );
};
