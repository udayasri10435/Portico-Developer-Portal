import React from 'react';
import { usePortal, NavigationTab } from '../../context/PortalContext';
import { Plus, Search, Sparkles } from 'lucide-react';

export const Header: React.FC = () => {
  const { activeTab, setActiveTab, setIsScaffolderModalOpen, setIsCommandPaletteOpen, setSelectedTemplate } = usePortal();

  const navItems: { id: NavigationTab; label: string }[] = [
    { id: 'catalog', label: 'Catalog' },
    { id: 'scaffolder', label: 'Golden Paths' },
    { id: 'scorecards', label: 'Scorecards' },
    { id: 'techdocs', label: 'TechDocs' },
    { id: 'graph', label: 'System Graph' },
    { id: 'dora', label: 'DORA Metrics' }
  ];

  const handleOpenCreateService = () => {
    setSelectedTemplate(null);
    setIsScaffolderModalOpen(true);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-slate-950/90 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 sm:px-6">
        {/* Zone 1: Single text element brand wordmark */}
        <button
          onClick={() => setActiveTab('catalog')}
          className="flex items-center gap-2.5 text-left transition-opacity hover:opacity-90"
        >
          <div className="flex h-7 w-7 items-center justify-center rounded bg-gradient-to-br from-indigo-500 to-indigo-700 text-white shadow-sm">
            <span className="font-mono text-sm font-bold tracking-tight">P</span>
          </div>
          <span className="text-base font-semibold tracking-tight text-white">
            Portico
          </span>
        </button>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-1 sm:gap-2">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`relative px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                  isActive
                    ? 'text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-2 right-2 h-0.5 bg-indigo-500" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsCommandPaletteOpen(true)}
            className="flex h-8 items-center gap-2 rounded border border-slate-800 bg-slate-900/80 px-2.5 text-xs text-slate-400 transition-colors hover:border-slate-700 hover:text-slate-200"
            title="Search catalog, templates and docs (Cmd+K)"
          >
            <Search className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Search IDP...</span>
            <kbd className="hidden sm:inline-block rounded bg-slate-800 px-1 py-0.5 font-mono text-[10px] text-slate-400">
              ⌘K
            </kbd>
          </button>

          <button
            onClick={handleOpenCreateService}
            className="flex h-8 items-center gap-1.5 rounded bg-indigo-600 px-3 text-xs font-medium text-white transition-colors hover:bg-indigo-500 active:bg-indigo-700 shadow-sm"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Create Service</span>
          </button>
        </div>
      </div>
    </header>
  );
};
