import React, { useState, useMemo } from 'react';
import { usePortal } from '../../context/PortalContext';
import {
  FileText,
  Search,
  BookOpen,
  ChevronRight,
  ExternalLink,
  Code2,
  Terminal,
  Copy,
  Check,
  CheckCircle2,
  AlertTriangle,
  Play
} from 'lucide-react';

export const TechDocsView: React.FC = () => {
  const { services, setSelectedServiceId } = usePortal();

  // Extract all docs from all services
  const allDocs = useMemo(() => {
    const list: { serviceId: string; serviceName: string; docId: string; title: string; content: string }[] = [];
    services.forEach((s) => {
      if (s.techDocs && s.techDocs.length > 0) {
        s.techDocs.forEach((d) => {
          list.push({
            serviceId: s.id,
            serviceName: s.name,
            docId: d.id,
            title: d.title,
            content: d.content
          });
        });
      }
    });
    return list;
  }, [services]);

  const [selectedDocKey, setSelectedDocKey] = useState<string>(
    allDocs[0] ? `${allDocs[0].serviceId}-${allDocs[0].docId}` : ''
  );
  const [search, setSearch] = useState('');
  const [copiedSnippet, setCopiedSnippet] = useState(false);

  const filteredDocs = useMemo(() => {
    if (!search) return allDocs;
    const q = search.toLowerCase();
    return allDocs.filter(
      (d) =>
        d.title.toLowerCase().includes(q) ||
        d.serviceName.toLowerCase().includes(q) ||
        d.content.toLowerCase().includes(q)
    );
  }, [allDocs, search]);

  const currentDoc = useMemo(() => {
    return (
      allDocs.find((d) => `${d.serviceId}-${d.docId}` === selectedDocKey) ||
      allDocs[0] ||
      null
    );
  }, [allDocs, selectedDocKey]);

  const activeService = services.find((s) => s.id === currentDoc?.serviceId);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSnippet(true);
    setTimeout(() => setCopiedSnippet(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            TechDocs & Engineering Knowledge Base
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Docs-like-code architecture decision records (ADRs), operational runbooks, and microservice specifications.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-mono">
            Synced from Git Markdown via CI/CD
          </span>
        </div>
      </div>

      {/* Docs Layout Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-start">
        {/* Left Docs Navigation Tree */}
        <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-4 space-y-4">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-500" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search documentation..."
              className="w-full rounded border border-slate-800 bg-slate-950 pl-8 pr-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none"
            />
          </div>

          <div className="space-y-1 max-h-[600px] overflow-y-auto">
            {filteredDocs.length === 0 ? (
              <div className="text-xs text-slate-500 p-2">No documents found</div>
            ) : (
              filteredDocs.map((doc) => {
                const key = `${doc.serviceId}-${doc.docId}`;
                const isSelected = selectedDocKey === key;
                return (
                  <button
                    key={key}
                    onClick={() => setSelectedDocKey(key)}
                    className={`flex flex-col w-full text-left rounded p-2.5 transition-colors ${
                      isSelected
                        ? 'bg-slate-800 text-white border-l-2 border-indigo-500'
                        : 'text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
                    }`}
                  >
                    <span className="text-xs font-semibold truncate">{doc.title}</span>
                    <span className="text-[10px] text-slate-500 font-mono mt-0.5">
                      {doc.serviceName}
                    </span>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Right Markdown Content Viewer */}
        <div className="md:col-span-3 rounded-lg border border-slate-800 bg-slate-900/40 p-6 space-y-6">
          {currentDoc && activeService ? (
            <div>
              {/* Document Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div>
                  <div className="flex items-center gap-2 text-xs text-slate-400 font-mono mb-1">
                    <span
                      onClick={() => setSelectedServiceId(activeService.id)}
                      className="text-indigo-400 hover:underline cursor-pointer"
                    >
                      {activeService.name}
                    </span>
                    <span>/</span>
                    <span>docs</span>
                  </div>
                  <h2 className="text-lg font-bold text-white">{currentDoc.title}</h2>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCopy(currentDoc.content)}
                    className="flex items-center gap-1.5 rounded border border-slate-800 bg-slate-950 px-2.5 py-1 text-xs text-slate-300 hover:bg-slate-800 transition-colors"
                  >
                    {copiedSnippet ? (
                      <Check className="h-3.5 w-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="h-3.5 w-3.5" />
                    )}
                    <span>{copiedSnippet ? 'Copied' : 'Copy Markdown'}</span>
                  </button>
                  <button
                    onClick={() => setSelectedServiceId(activeService.id)}
                    className="flex items-center gap-1 rounded bg-slate-800 px-2.5 py-1 text-xs text-slate-200 hover:bg-slate-700 transition-colors"
                  >
                    <span>View Component</span>
                    <ChevronRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>

              {/* Rendered Content */}
              <div className="pt-4 space-y-4 text-xs text-slate-300 leading-relaxed font-sans">
                <div className="whitespace-pre-wrap font-mono text-xs bg-slate-950/70 p-4 rounded-lg border border-slate-800 text-slate-200 overflow-x-auto">
                  {currentDoc.content}
                </div>
              </div>

              {/* Component Info Card at bottom */}
              <div className="mt-8 border-t border-slate-800 pt-5 flex items-center justify-between text-xs text-slate-400">
                <div>
                  Maintained by <span className="font-semibold text-slate-200">{activeService.ownerTeam}</span>
                </div>
                <div className="font-mono text-slate-500">
                  Last updated {activeService.updatedAt}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-12 text-center text-xs text-slate-500">
              Select a document from the left navigation tree.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
