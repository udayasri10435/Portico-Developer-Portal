import React from 'react';
import { usePortal } from '../../context/PortalContext';
import {
  TrendingUp,
  Clock,
  AlertTriangle,
  RotateCcw,
  Zap,
  CheckCircle2,
  ShieldCheck,
  Activity,
  ArrowUpRight
} from 'lucide-react';

export const DoraMetricsView: React.FC = () => {
  const { services, setSelectedServiceId, setAuditDrawerServiceId } = usePortal();

  // Compute aggregate DORA stats across all catalog services
  const totalServices = services.length || 1;
  const avgUptime = (
    services.reduce((acc, s) => acc + s.metrics.uptime, 0) / totalServices
  ).toFixed(3);

  const avgLeadTime = (
    services.reduce((acc, s) => acc + s.metrics.leadTimeHours, 0) / totalServices
  ).toFixed(1);

  const avgChangeFailRate = (
    services.reduce((acc, s) => acc + s.metrics.changeFailureRate, 0) / totalServices
  ).toFixed(1);

  const avgMttr = Math.round(
    services.reduce((acc, s) => acc + s.metrics.mttrMinutes, 0) / totalServices
  );

  // At-risk services (e.g. failing scorecard rules or high MTTR)
  const atRiskServices = services.filter(
    (s) => s.scorecard.scorePercent < 85 || s.metrics.changeFailureRate > 2.5
  );

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            DORA Metrics & Engineering Reliability
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            DevOps Research and Assessment (DORA) benchmarks and real-time operational telemetry across all engineering teams.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="rounded bg-emerald-950 border border-emerald-800 px-2.5 py-1 text-xs font-semibold text-emerald-400 font-mono">
            Organization Tier: ELITE
          </span>
        </div>
      </div>

      {/* The 4 Core DORA Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Deployment Frequency */}
        <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-4 relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>Deployment Frequency</span>
            <span className="text-emerald-400 font-semibold">ELITE</span>
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums mt-2">
            4.8 / day
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Multiple deploys per day to production across microservices
          </p>
          <div className="mt-3 text-[10px] text-emerald-400 flex items-center gap-1 font-mono">
            <ArrowUpRight className="h-3 w-3" />
            <span>+18% velocity vs prior quarter</span>
          </div>
        </div>

        {/* Metric 2: Lead Time for Changes */}
        <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-4 relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>Lead Time for Changes</span>
            <span className="text-emerald-400 font-semibold">ELITE</span>
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums mt-2">
            {avgLeadTime} hours
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            From git commit to running in production cluster
          </p>
          <div className="mt-3 text-[10px] text-emerald-400 flex items-center gap-1 font-mono">
            <ArrowUpRight className="h-3 w-3" />
            <span>Target &lt; 2 hours met</span>
          </div>
        </div>

        {/* Metric 3: Change Failure Rate */}
        <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-4 relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>Change Failure Rate</span>
            <span className="text-emerald-400 font-semibold">ELITE</span>
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums mt-2">
            {avgChangeFailRate}%
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Deployments requiring hotfix or rollback
          </p>
          <div className="mt-3 text-[10px] text-emerald-400 flex items-center gap-1 font-mono">
            <CheckCircle2 className="h-3 w-3" />
            <span>Benchmark: 0 - 15%</span>
          </div>
        </div>

        {/* Metric 4: Time to Restore Service (MTTR) */}
        <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-4 relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>Mean Time to Recover (MTTR)</span>
            <span className="text-emerald-400 font-semibold">ELITE</span>
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums mt-2">
            {avgMttr} mins
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Time to recover from an unplanned degradation
          </p>
          <div className="mt-3 text-[10px] text-emerald-400 flex items-center gap-1 font-mono">
            <CheckCircle2 className="h-3 w-3" />
            <span>Benchmark: &lt; 60 mins</span>
          </div>
        </div>
      </div>

      {/* Team DORA Velocity Table */}
      <div className="rounded-lg border border-slate-800 bg-slate-900/40 p-5 space-y-4">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
          Squad-Level DORA Breakdown
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-800 bg-slate-950/60 text-[11px] font-medium uppercase tracking-wider text-slate-400 font-mono">
              <tr>
                <th className="py-2.5 px-3">Squad</th>
                <th className="py-2.5 px-3 text-right">Deploy Rate</th>
                <th className="py-2.5 px-3 text-right">Lead Time</th>
                <th className="py-2.5 px-3 text-right">Change Fail %</th>
                <th className="py-2.5 px-3 text-right">MTTR</th>
                <th className="py-2.5 px-3 text-right">Uptime</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {[
                { squad: 'Identity & Access', deploys: '6.4 / day', lead: '0.8h', fail: '0.8%', mttr: '8m', uptime: '99.995%' },
                { squad: 'Checkout & Payments', deploys: '4.8 / day', lead: '1.2h', fail: '1.4%', mttr: '12m', uptime: '99.98%' },
                { squad: 'Platform Core', deploys: '3.6 / day', lead: '1.5h', fail: '1.0%', mttr: '14m', uptime: '99.97%' },
                { squad: 'Trust & Safety', deploys: '5.1 / day', lead: '1.0h', fail: '1.1%', mttr: '16m', uptime: '99.96%' },
                { squad: 'Supply Chain & Fulfillment', deploys: '2.1 / week', lead: '4.8h', fail: '3.5%', mttr: '32m', uptime: '99.92%' },
                { squad: 'Data Eng & Search', deploys: '1.0 / week', lead: '6.2h', fail: '5.8%', mttr: '45m', uptime: '99.85%' }
              ].map((row) => (
                <tr key={row.squad} className="hover:bg-slate-800/20">
                  <td className="py-2.5 px-3 font-sans font-medium text-slate-200">{row.squad}</td>
                  <td className="py-2.5 px-3 text-right text-slate-300">{row.deploys}</td>
                  <td className="py-2.5 px-3 text-right text-slate-300">{row.lead}</td>
                  <td className="py-2.5 px-3 text-right text-slate-300">{row.fail}</td>
                  <td className="py-2.5 px-3 text-right text-slate-300">{row.mttr}</td>
                  <td className="py-2.5 px-3 text-right text-emerald-400 font-semibold">{row.uptime}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Drift & At-Risk Services */}
      <div className="rounded-lg border border-slate-800 bg-slate-900/40 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Drift Detector & At-Risk Components ({atRiskServices.length})
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Components requiring remediation to maintain Gold / Platinum compliance.
            </p>
          </div>
        </div>

        <div className="space-y-2.5">
          {atRiskServices.map((svc) => (
            <div
              key={svc.id}
              className="flex items-center justify-between rounded border border-amber-900/40 bg-amber-950/20 p-3"
            >
              <div className="flex items-center gap-3">
                <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0" />
                <div>
                  <button
                    onClick={() => setSelectedServiceId(svc.id)}
                    className="text-xs font-semibold text-slate-200 hover:text-indigo-400 transition-colors"
                  >
                    {svc.name}
                  </button>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {svc.ownerTeam} · Scorecard at {svc.scorecard.scorePercent}% ({svc.scorecard.overallGrade})
                  </div>
                </div>
              </div>

              <button
                onClick={() => setAuditDrawerServiceId(svc.id)}
                className="rounded bg-amber-900/60 border border-amber-700 px-2.5 py-1 text-xs font-medium text-amber-200 hover:bg-amber-800/80 transition-colors"
              >
                Remediate Checks
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
